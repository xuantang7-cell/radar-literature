# -*- coding: utf-8 -*-
"""radar-cloud 最小能力探活脚本。

验证五件事：
1. python 可用且版本正常（脚本需要 3.8+，仅标准库）
2. 凭据可用（radar/.env 或环境变量）—— 推送与 OpenAlex 额度都依赖它
3. 三个文献 API（Europe PMC / Crossref / OpenAlex）从当前网络可达
4. 当前工作目录可写文件、可读回
5. 目录结构完整（scripts/config/references/data 都在）

三态结论（2026-09-11 起）：
  PASS —— 该能力可用。
  WARN —— 可用性受损但**不阻塞**本次运行：单个数据源限流/额度耗尽（代码会降源
          并在报告头部如实标注），或缺凭据（推送会被跳过）。**必须写进汇报。**
  FAIL —— 硬失败，必须停下：python 版本/标准库/文件读写/包结构/配置/自家模块导入，
          或三个数据源全部不可用（那就没有可用的检索通路了）。

为什么要有 WARN：旧版把「OpenAlex 429」一律记成 FAIL，于是每次都要让运行者去判断
"这个 FAIL 到底能不能继续"——师妹首跑与 2026-09-09 云端两次都在这里卡过。而 429 的
真实成因是**额度**（无 Key 1000 credits/天、按出口 IP 共享），不是环境不能跑。

退出码：有 FAIL 才为 1；只有 WARN 时为 0。

用法：python3 probe.py    （若无 python3，试 python probe.py）
"""

import os
import sys
import urllib.error
import urllib.parse
import urllib.request

RESULTS = []

SCRIPTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scripts")
if os.path.isdir(SCRIPTS_DIR) and SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, SCRIPTS_DIR)

try:
    from common import load_dotenv_if_present, quota_exhausted, quota_snapshot
except Exception as exc:  # pragma: no cover - 包结构损坏时的兜底
    # 探活脚本要自证"这个包是完整可运行的"：连自家 scripts/common.py 都导入不了，
    # 说明包已损坏，流水线必然跑不起来。这是硬失败，不能降级成 WARN。
    print("[FAIL] 导入 scripts/common.py  %s: %s" % (type(exc).__name__, exc))
    print("包结构已损坏（scripts/common.py 不可导入），无法继续。请重新下载自举包。")
    sys.exit(1)


def check(name, level, detail=""):
    RESULTS.append((name, level, detail))
    print("[%s] %s  %s" % (level, name, detail))


def http_get(url, timeout=20, headers=None):
    """返回 (状态码, 响应头 dict)；HTTP 错误也返回状态码而不抛异常。

    状态码 0 表示连响应都没有（DNS/超时/TLS 失败），详情在 headers["_error"]。
    """
    request_headers = {"User-Agent": "radar-cloud-probe/1.0"}
    if headers:
        request_headers.update(headers)
    request = urllib.request.Request(url, headers=request_headers)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            response.read(400)
            return response.status, dict(response.headers)
    except urllib.error.HTTPError as exc:
        return exc.code, dict(exc.headers or {})
    except Exception as exc:  # noqa: BLE001
        return 0, {"_error": "%s: %s" % (type(exc).__name__, exc)}


def describe_quota(headers):
    """把 X-RateLimit-* 写成一行结论；字段缺失就不写，不编造。"""
    snapshot = quota_snapshot(headers)
    parts = []
    remaining = snapshot.get("X-RateLimit-Remaining")
    limit = snapshot.get("X-RateLimit-Limit")
    if remaining is not None and limit is not None:
        parts.append("额度剩余 %d/%d" % (remaining, limit))
    elif remaining is not None:
        parts.append("额度剩余 %d" % remaining)
    used = snapshot.get("X-RateLimit-Credits-Used")
    if used is not None:
        parts.append("本次消耗 %d credits" % used)
    reset = snapshot.get("X-RateLimit-Reset")
    if reset is not None:
        parts.append("约 %.1f 小时后重置（UTC 00:00）" % (reset / 3600.0))
    return "，".join(parts)


def classify_openalex(status, headers, has_key):
    """OpenAlex 单项探活的结论分类（纯函数，便于测试）。

    关键：429 的两种成因处置完全不同。
      · 额度耗尽（Remaining == 0）—— 当日无法恢复（重置在 UTC 00:00）。报 FAIL
        会让人以为"环境不能跑"；实际它只是该源今日缺席，Europe PMC 与 Crossref
        仍能完成检索 → 报 WARN，并给出重置时间。
      · 瞬时拥塞（Remaining > 0）—— 代码会退避重试，同样 WARN。
    """
    quota_text = describe_quota(headers)
    if status == 200:
        if has_key:
            return "PASS", "HTTP 200（已带 API Key，额度按账号计）" + ("；" + quota_text if quota_text else "")
        return (
            "WARN",
            "HTTP 200（**未配置 OPENALEX_API_KEY**，走匿名额度：实测 1000 credits/天"
            "且按出口 IP 共享，易被同 IP 他人耗尽）" + ("；" + quota_text if quota_text else ""),
        )
    if status == 429:
        if quota_exhausted(headers):
            return (
                "WARN",
                "HTTP 429 **当日额度已耗尽**（" + (quota_text or "未返回额度头")
                + "）。本源本次将缺席，检索由 Europe PMC + Crossref 完成，不阻塞运行；"
                "根因是额度而非网络，配一个免费 OPENALEX_API_KEY 即可解决",
            )
        return (
            "WARN",
            "HTTP 429 限流（" + (quota_text or "未返回额度头")
            + "）：额度尚有余量，属瞬时拥塞，本次运行会退避重试",
        )
    if status == 0:
        return "WARN", "网络不可达：" + headers.get("_error", "未知原因")
    return "WARN", "HTTP %d（非 200，服务器有响应）" % status


def main():
    print("=== 1. python 环境 ===")
    check("python 版本", "PASS" if sys.version_info >= (3, 8) else "FAIL", sys.version.split()[0])
    stdlib_ok = all(True for m in ["json", "urllib", "gzip", "zlib"] if __import__(m))
    check("标准库完整", "PASS" if stdlib_ok else "FAIL", "json/urllib/gzip/zlib")

    print("=== 2. 凭据加载 ===")
    loaded = load_dotenv_if_present()
    credential_keys = ("WXPUSHER_APP_TOKEN", "WXPUSHER_UID", "OPENALEX_MAILTO", "OPENALEX_API_KEY")
    present = [k for k in credential_keys if os.environ.get(k, "").strip()]
    if present:
        source = "其中 %d 项由 .env 补载" % len(loaded) if loaded else "来自已导出的环境变量"
        check("凭据可用", "PASS", "已就绪：" + ", ".join(present) + "（" + source + "）")
    else:
        check(
            "凭据可用",
            "WARN",
            "未发现任何凭据：WxPusher 推送会被跳过，OpenAlex 走匿名额度（值不回显）",
        )
    push_ready = all(os.environ.get(k, "").strip() for k in ("WXPUSHER_APP_TOKEN", "WXPUSHER_UID"))
    check(
        "WxPusher 推送凭据",
        "PASS" if push_ready else "WARN",
        "APP_TOKEN 与 UID 均已就绪" if push_ready else "缺 WXPUSHER_APP_TOKEN 或 WXPUSHER_UID，推送会被跳过",
    )

    print("=== 3. 三源 API 网络可达性 ===")
    mailto = os.environ.get("OPENALEX_MAILTO", "").strip()
    has_key = bool(os.environ.get("OPENALEX_API_KEY", "").strip())
    openalex_url = "https://api.openalex.org/works?per_page=1"
    openalex_headers = {}
    if has_key:
        openalex_headers["Authorization"] = "Bearer " + os.environ["OPENALEX_API_KEY"].strip()
    if mailto:
        openalex_url += "&mailto=" + urllib.parse.quote(mailto)

    probes = [
        (
            "Europe PMC",
            "https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=test&format=json&pageSize=1",
            None,
        ),
        ("Crossref", "https://api.crossref.org/works?rows=1", None),
        ("OpenAlex", openalex_url, openalex_headers or None),
    ]
    reachable = 0
    for name, url, headers in probes:
        status, response_headers = http_get(url, headers=headers)
        if name == "OpenAlex":
            level, detail = classify_openalex(status, response_headers, has_key)
        else:
            level = "PASS" if status == 200 else "WARN"
            detail = "HTTP %d" % status if status else "网络不可达：" + response_headers.get("_error", "未知原因")
        if status == 200:
            reachable += 1
        check("%s 可达" % name, level, detail)

    print("=== 4. 文件写读 ===")
    try:
        with open("_probe_write_test.txt", "w", encoding="utf-8") as f:
            f.write("probe-ok-中文")
        with open("_probe_write_test.txt", encoding="utf-8") as f:
            content = f.read()
        os.remove("_probe_write_test.txt")
        check("文件写读", "PASS" if content == "probe-ok-中文" else "FAIL", "cwd=" + os.getcwd())
    except Exception as exc:  # noqa: BLE001
        check("文件写读", "FAIL", "%s: %s" % (type(exc).__name__, exc))

    print("=== 5. 包结构 ===")
    for d in ["scripts", "config", "references", "data", "data/runs"]:
        check("目录存在: " + d, "PASS" if os.path.isdir(d) else "FAIL")
    cfg_ok = os.path.isfile("config/research_profile.json")
    check("配置存在", "PASS" if cfg_ok else "FAIL", "config/research_profile.json")
    if cfg_ok:
        try:
            import json as _json

            with open("config/research_profile.json", encoding="utf-8") as f:
                profile = _json.load(f)
            check(
                "配置可解析",
                "PASS" if profile.get("configured") else "FAIL",
                "profile_name=%s" % profile.get("profile_name"),
            )
        except Exception as exc:  # noqa: BLE001
            check("配置可解析", "FAIL", "%s: %s" % (type(exc).__name__, exc))

    print()
    fails = [r for r in RESULTS if r[1] == "FAIL"]
    warns = [r for r in RESULTS if r[1] == "WARN"]
    print("共 %d 项检查：PASS %d / WARN %d / FAIL %d" % (len(RESULTS), len(RESULTS) - len(fails) - len(warns), len(warns), len(fails)))
    if warns:
        print("WARN（不阻塞，但必须写进汇报）：")
        for name, _, detail in warns:
            print("  WARN %s: %s" % (name, detail))
    if fails:
        print("FAIL（硬失败，必须停下）：")
        for name, _, detail in fails:
            print("  FAIL %s: %s" % (name, detail))
        sys.exit(1)
    if reachable == 0:
        print("FAIL 三个数据源全部不可用，没有任何可用的检索通路。")
        sys.exit(1)
    print("无 FAIL：此沙箱具备运行文献雷达脚本的基本条件；请照上面把 WARN 一并汇报。")
    sys.exit(0)


if __name__ == "__main__":
    main()

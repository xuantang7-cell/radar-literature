---
name: research-paper-daily-push
description: 根据用户配置的研究方向，检索、复核、评分、去重并中文总结近期科研论文，同时维护研究记忆并可选推送到微信。适用于每日或每周精选文献雷达；不适用于穷尽式系统综述或仅做参考文献格式整理的任务。
---

# 每日科研文献雷达

生成高选择性的中文文献雷达，不能把关键词检索结果直接堆给用户。每天最多推荐5–10篇证据充分且推荐指数不低于70分的论文；证据不足时允许少于5篇或零推荐。每篇论文中实际使用的专业术语都要给出两种解释：一条严谨的学术定义和一条忠实、易懂的比喻或大白话解释。

## 配置边界

证据复核前先阅读 [`references/research_topics.md`](references/research_topics.md)，并使用 `config/research_profile.json` 进行确定性检索和初步评分。公开配置有意留空；如果 `configured` 为 `false`，停止检索并帮助用户配置研究方向，不能臆造主题，也不能悄悄套用内置示例。引导配置时按 [`references/config_wizard.md`](references/config_wizard.md) 的六段流程逐步进行；创建或修改配置时阅读 [`references/profile_schema.md`](references/profile_schema.md)。

自然语言主题文件负责科学解释，JSON配置负责 API 查询、主题词组、聚焦模式、初筛权重、期刊分层、排除条件、强烈推荐条件、研究路线分类和标签词表。两者必须保持一致。

## 期刊白名单与双通道

如果 `config/research_profile.json` 配置了 `journal_gate`，期刊是**硬过滤**：不在白名单内的论文一律剔除，即使主题命中很强。这是本配置的筛选轴——筛的是期刊水平，不是主题相关性。

两个通道用的是同一套主题的两层口径，不是两套并列体系：

- **窄层** = `topic_groups`（配置关注的那几个细分方向）
- **宽层** = `topic_groups_channel_b`（任意药物递送细分）

| | 通道 A（主题驱动） | 通道 B（顶刊驱动） |
|---|---|---|
| 期刊 | 通道 A 白名单（**28 本**） | 正刊与大子刊（**17 本**） |
| 主题 | **必须命中窄层** | 命中**宽层**即可 |
| 判定 | 双重窄口径 | 顶刊发递送本身是罕见事件 |

复述规则：

1. **通道是单值**：一篇论文只属于 A 或 B，不标"双通道"。两本名单互不重叠，写重了以 B 为准。
2. **顶刊额外命中窄层 → 加分提优先级**，用 `priority_bonus` 表达，不是加第二个通道标签。这条加分的语义是「顶刊上出现自己最关注的细分方向，比顶刊上的普通递送论文更值得读」。
3. **白名单外剔除要在报告里说明数量**，不能静默丢掉。删选数量见 `rank_payload` 输出的 `not_in_allowlist_count` 与 `channel_counts`。
4. **接受零推荐**：某周白名单内没有达标论文是正常结果，不得为凑数降低阈值或放宽到白名单外。
5. 新增白名单期刊前，必须先实测该刊在数据源里的真实写法再写进 `aliases`。**Europe PMC 的 `JOURNAL:` 字段只索引 MEDLINE 缩写**，照抄规范全称会静默失配（详见 [`references/profile_schema.md`](references/profile_schema.md)）。

## 工作流程

1. 运行 `python scripts/run_daily.py collect --mode <mode>`。`all` 使用默认查询，聚焦模式名称来自研究配置。命令默认查询 **Europe PMC、Crossref、OpenAlex 三个来源**（`--sources` 可手动指定，全部支持项为 europepmc / crossref / openalex / semanticscholar / biorxiv），按 DOI 优先、题名兜底合并重复记录、摘要取最长，排除确认推送过的论文，并写入 `data/runs/YYYY-MM-DD/review_queue.json`。默认不用 Semantic Scholar（无 API Key 时限流严重，实测 HTTP 429）与 bioRxiv（只出预印本，白名单全为正式期刊，命中后必被 gate 剔除）。OpenAlex 可匿名检索，并使用游标读取每条查询最多600条近期记录；**强烈建议配置 `OPENALEX_API_KEY`**（免费、约 30 秒，额度按账号计且为匿名额度的 10 倍；匿名额度实测 1000 credits/天且**按出口 IP 共享**，而本流程单次最坏消耗 840 credits，故匿名时经常 429），并配 `OPENALEX_MAILTO`。两者都从环境变量读取——推荐写进 `radar/.env`（脚本启动时自动补载），**不能写入仓库或日志**。
2. 固定使用最近7天的候选池（学术接口只提供日级出版日期，无法可靠判定“近24小时”）。新鲜度不再通过“是否扩窗”表达，而是由 `rank_papers.py` 的分层名额保证：近 `--fresh-days`（默认2）天内出版的达标论文构成新鲜层，最多占用队列名额的 `--fresh-share`（默认50%），其余名额由更早的达标论文按初筛分补足；两层内部各按初筛分降序，新鲜层排在前面以便优先复核。
   - `--threshold`（默认45）是**程序初筛的入队线**，不是最终推荐线。它只决定哪些论文进入候选队列供证据复核，定得比最终推荐线（70分）低是刻意的：初筛是**宽进**，靠关键词召回；若入队线也设 70，等于要求同时命中多个细分方向，会把「符合一个方向即可」的论文全部拒之门外。（2026-09-08 注：旧的「单组命中 relevance 保底 50」已随 `relevance` 改为准入条件一并移除。）最终推荐仍以第5–7步的证据复核为准，不受此影响。
   - **单组命中 relevance 保底 50**（2026-09-04 裁定）：topic_groups 的 `weight`（L1=46/L2=38/L3=36）本意是多组累加时体现主题次序，但不能把单组命中的论文压死——保底前纯 L3 肺部单命中（36）即便内容全优总分也只有 69.65，差 0.35 到 70 推荐线，该主题形同虚设。保底只作用于恰好命中一个组的论文（`score_relevance` 中 `raw<50` 时抬到 50），多组命中（raw≥74）不受影响，鼻-脑论文靠天然双命中（L1+L2）保持排序优势。
   - `--max-results` 是**候选队列上限**，不是最终推荐量。复核淘汰率通常在50%–60%，所以要保证复核后有5–10篇最终推荐，候选上限应显著大于该数量（鼻-脑递送方向实测建议 `--max-results 40`，2026-09-09 由 25 上调）。上限过小会静默丢弃达标候选，包括高分真阳性。
     - **为什么上调到 40（2026-09-09 实测）**：初筛词表对方法学创新识别能力弱——本次入选 #3/#4/#7 的初筛分只有 64/57/64，全靠三维复核救回到 89/88/84。但**能被救回的前提是它们排进了队列**：漏斗 5835 → 389 → 25，取的是初筛分 top，排在 25 名之后的论文**复核环节根本看不到**，永远不会被"救回"。因此不能用"已进队列的都被救回了"反推"初筛不重要"——那是幸存者偏差。
     - 与其调词表（需标注数据、反复试、易回退），**扩队列是同效果的低成本杠杆**：改一个参数即可给复核多看 15 篇，代价只有 AI token 约 +60%，单篇质量不变。
   - `--min-results` 只是**预警下限**：候选数低于它时打印警告并在 `metadata.below_min_results` 标记，**不再触发扩窗**。真实达标数由第5步的证据复核决定，不能用程序初筛分代替。
3. 阅读限定长度的 `research_memory_context`、候选题名、摘要、元数据、评分证据和待核实提示。研究记忆只用于发现连续证据、未解决问题、研究空白和重复思路，不能当成用户明确偏好的证明。
4. 对可能入选的论文进行证据核验。如果摘要缺失、截断、相互矛盾或不足以支持实质性结论，优先核对 DOI 与 Europe PMC：**EPMC 返回 `pmcid` 说明该文有 OA 全文被 PMC 收录，可读其 Methods 部分核实方法学细节**。不要依赖出版商页面——实测其普遍有付费墙或反爬（nature.com 走 Cloudflare 人机验证，OA 也进不去；Wiley 只返回标题；Elsevier 未登录只能看被截断的片段），在半截内容上核对容易脑补出不存在的方法学证据。EPMC 查 DOI 时**不要给 DOI 加引号**（`DOI:10.1038/xxx` 才命中，`DOI:"10.1038/xxx"` 返回 0 条）。不能只根据题名推断结果。
5. 证据复核后重新评价每篇候选。**推荐指数 = 三层面权重公式**：

   | 阶段 | 公式 | 谁决定 |
   |---|---|---|
   | ① 初筛分 | `relevance*0.13 + quality*0.87`，relevance = 三轴 R/F/D 关键词判读的契合度分 | 元数据词表 + 期刊档位 |
   | ② 最终分 | `0.10·rel + 0.20·content + 0.70·qual`，rel = AI 判三轴、content = 4 项平均 + 3 加分、qual = 期刊档位 | 你的三轴 + 内容判定 |

   即：**初筛分只做砍量 + 粗排，最终分由你的三轴 + 内容判定重算**。`qual` 只看期刊档位（L0–L4 = 100/92/80/75/70），`relevance`（三轴 rel）的数值表达契合度高低——核心方向（R=1.0）rel≥52，非核心方向（R=0.4）rel≤40。若启用白名单且该论文属于通道 B 又额外命中窄层细分方向，最终分还会在加权总分之外叠加 `priority_bonus`（封顶100），并在 `score_evidence.priority` 给出说明。只有检查过可用证据后，才能把 `score_status` 设为 `evidence_reviewed`。复核时必须阅读摘要，判定每篇是「综述」还是「研究论文」，把 `article_type` 改写为判定值——**不能照抄检索源的类型标签**（`Journal Article` / `journal-article` / `article` 无法区分综述，且 Crossref 与 OpenAlex 常把综述误标为 article，只凭题名也不可靠，必须以摘要内容为准）。

   复核时还须判定**递送系统在本研究中的地位**，写入 `delivery_centrality`（必填，三选一：`core`/`tool`/`non_delivery`）。判据见 [`references/domain_judgment.md`](references/domain_judgment.md) 第 1 节。
6. 排除弱相关论文、重复论文、撤稿/勘误/社论、明显可疑来源、命中配置排除条件的研究，以及关键主张无法核实的论文。预印本要明确标注为未经过正式同行评议。陌生期刊应标记“需要核实”，不能直接判定为低质量。
7. 只保留证据充分且评分不低于70分的论文，按推荐指数降序排列，不为凑数降低标准。**70 分线由 `summarize_papers.py` 代码层强制**（`--min-score` 默认70，低于该分的论文即使写入 `reviewed_articles.json` 也会在渲染时被剔除并在报告头部说明），复核时低于 70 的候选不必写入。按照下方数据约定编写 `reviewed_articles.json`，把根字段 `term_explanation_mode` 设为 `dual`，然后运行 `python scripts/summarize_papers.py --input <reviewed.json> --output <report.md>`。
8. 只有用户或定时任务提示词明确授权外部推送时，才能运行 `python scripts/run_daily.py deliver --reviewed <reviewed.json> --report <report.md> --provider auto`。报告已经在本地真实展示时，可使用 `--skip-push --record-local-report`。只有确认推送或展示成功后，交付阶段才更新去重历史和研究记忆。

## 证据与写作规则

明确区分直接实验依据、相关性、假设和推测。使用审慎的正式科学中文。不得捏造题名、研究对象、方法、样本、数值、DOI、机制或数据集；证据不支持的细节写明“需要核实”。

每篇论文提供：忠实中文题名和英文原题、期刊/日期/DOI/链接/文章类型、总分和分项评分、以「问题→策略→结果」逻辑链写成的推荐理由（自然论述句，篇幅克制，并收尾点明与团队方向的相关性价值）、至少1条受证据约束的核心发现（讲清楚即可、不凑字数），以及针对实验设计、方法、关键对象或机制、目标研究体系、未来课题或基金、高水平论文潜力和局限/验证需求的具体启发。存在研究路线阶段时，说明论文对应的阶段。拉丁学名和适用的基因名称使用斜体。添加1–8个聚焦标签。

只有证据充分，并且人工复核后满足配置的强烈推荐规则，才能设置 `strong_recommendation: true`。单纯关键词命中不能触发强烈推荐。

报告层面应包含检索/筛选/最终推荐数量、最值得阅读前三名及理由，并结合当天证据提出1–3个可检验的研究思路。

## 专业术语双重解释

覆盖中文题名、核心发现、研究启发或强烈推荐理由中实际引入的所有专业术语，包括相关方法、领域概念、机制、结构、统计学术语、计算方法和命名通路/框架。同一篇论文中的相同术语和明显别名只解释一次。

- `term_en`：术语的英文原词，让学生认识并能在写作中正确使用（避免中文直译）。
- `academic_explanation`：技术上准确的定义，说明术语是什么，并在必要时说明其测量或支持的内容；讲清楚即可，不设字符上限。
- `plain_explanation`：具体的比喻或大白话解释，同时保持科学边界；讲清楚即可，不设字符上限。

术语定义不是论文证据。不能把相关性写成因果，也不能把比喻当作真实机制。

## 已复核JSON数据约定

根对象包含 `date`、`term_explanation_mode`、`metadata`、`articles` 和 `research_ideas`。每篇论文使用以下结构：

> **`research_ideas` 锚定红线（2026-09-07 用户裁定）**：每一条灵感只能基于**本期被推荐的论文**，并在句中点明来源（写「第N篇」、论文中文标题或其重点标记标签均可）。**不得引用本期推荐列表里不存在的文献**——历史批次、会话上下文或模型记忆里的内容都不算本期证据。代码层会做锚定校验：无法匹配到本期任何条目的灵感将被自动删除，并在报告头部注明删除条数。宁可少一条，不能出现「本期」标签下挂着本期找不到的文献。

```json
{
  "title": "英文原题",
  "chinese_title": "忠实中文题名",
  "journal": "期刊名称",
  "publication_date": "YYYY-MM-DD",
  "doi": "10.xxxx/xxxx",
  "url": "https://...",
  "article_type": "综述或研究论文（复核读摘要后的判定值，不照抄源标签）",
  "delivery_centrality": "core|tool|non_delivery（递送系统在本研究中的地位，判据见 references/domain_judgment.md 第 1 节）",
  "route_class": "nasal_brain|other_cns|pulmonary|non_delivery|out_of_scope（给药途径，**先判此项**；后两者直接定性排除、不打分）",
  "R": 1.0,
  "F": 0.85,
  "D": 1.0,
  "evidence_chain": 80,
  "bottleneck": 85,
  "mechanism_novelty": 75,
  "structure_activity": 70,
  "content_rationale": {
    "bottleneck": "为什么这个分",
    "evidence_chain": "为什么这个分（须围绕 bottleneck 讲闭环）",
    "mechanism_novelty": "为什么这个分",
    "structure_activity": "为什么这个分"
  },
  "in_vivo_evidence": 1,
  "efficacy_causality": 1,
  "transfer_inspiration": 1,
  "recommendation_score": 80,
  "score_status": "evidence_reviewed",
  "component_scores": {
    "relevance": 90,
    "quality": 85
  },
  "why_worth_reading": "问题→策略→结果的完整论述句，收尾点明与团队方向的相关性",
  "core_findings": ["至少1条受证据约束的结论，讲清楚即可"],
  "term_explanations": [
    {
      "term": "专业术语（中文）",
      "term_en": "English original term",
      "academic_explanation": "严谨解释",
      "plain_explanation": "保持科学边界的大白话解释"
    }
  ],
  // 只有三项必填（experimental_design / future_direction / limitations_validation），
  // 其余四类有则写、无则留空——不要为凑满七行硬写，宁缺毋滥
  "research_inspiration": {
    "experimental_design": ["..."],
    "methods": ["..."],
    "key_entities_mechanisms": ["...或需要核实"],
    "target_system": ["..."],
    "future_direction": ["..."],
    "paper_potential": ["..."],
    "limitations_validation": ["..."]
  },
  "top3_reason": "可选：本期内容分前三会展示这句，写给团队年轻学生看——这篇在方法/证据链上值得学哪一点；不要复述推荐理由",
  "tags": ["主题标签"],
  "strong_recommendation": false,
  "strong_recommendation_reasons": [],
  "needs_verification": [],
  "research_team": {"members": [], "source": "openalex_corresponding", "confidence": "high", "note": "由 enrich_team.py 自动补全，勿手写"}
}
```

### R / F / D 三轴契合度（v13 新增 · 阶段 4 落地，代码阶段 5 实现）

读摘要判三轴，量化契合度用于排序。**判定顺序：先判 route_class / delivery_centrality 的排除项（non_delivery / out_of_scope），被判排除的论文不判三轴、不算 rel**；只有保留的研究才判三轴。三轴是「契合度」不是「质量分」——非核心方向的 rel 上限约 40，核心方向的 rel 下限约 52。

`route_class` 五值与 `out_of_scope`「双非」判据见 [`references/domain_judgment.md`](references/domain_judgment.md) 第 2 节；三轴档位语义与契合度公式见同文档第 3 节（R = primary、D = modulators[0]、F = modulators[1]，档位值与词表以 config 的 `relevance_axes` 为准）。

### 内容评价（v13 新增 · 代码阶段 5 实现）

读摘要判「文献本身内容质量」，与三轴「契合度」正交（一篇方向边缘但内容扎实的文献，三轴低、内容可以高分）。**综述内容层降级：不评内容项**，价值由「三轴 + 期刊」体现。

- 通用评分维度（0–100 整数，**简单平均**，引擎内置、换领域不变），**判定顺序固定为：
  真实瓶颈 → 证据链 → 机制新颖 → 构效可迁移**（2026-09-16 用户裁定）：
  `bottleneck`（针对真实瓶颈）、`evidence_chain`（证据链是否围绕该瓶颈闭环）、`mechanism_novelty`（机制/范式新颖）、`structure_activity`（构效可迁移）
- **`evidence_chain` 评分口径（2026-09-16 用户裁定，区别于旧"链条长不长"）**：证据链必须**围绕它声称的瓶颈**来闭环，而不是"有药效就完整"。
  反例：针对「鼻腔清除机制限制滞留时间」开发的鼻腔原位凝胶，若实验只测了相变与黏度增大、没真正考察鼻腔滞留时间，即便有完整体内药效，也不算证据链完整。
  写 `content_rationale.evidence_chain` 时要写**论证链的结构与缺口**（制剂表征→体外→体内→疗效，哪环支撑哪环、断在哪），
  不要罗列"活体成像/脑分布"这类**单个核心证据**——核心证据回答"发现了什么"，证据链回答"怎么一环扣一环论证的"。
- **`content_rationale`（研究论文必填）**：给每个内容维度写一句「为什么这个分」。分数没有依据就是拍脑袋，学生也无法从"95 分"里学到东西；反过来，写不出理由就不该给这个分。综述内容层降级、不评内容，故不要求。
- 领域专属评分维度与加分项：见 config 的 `content_scoring` 与 [`references/domain_judgment.md`](references/domain_judgment.md) 第 4 节

最终分 = `0.10·rel + 0.20·content + 0.70·qual`，其中 content = 评分维度平均 + 加分项。综述 = `(0.10·rel + 0.70·qual)/0.80`。

### 研究团队 research_team（2026-09-16 新增 · 由脚本自动补全，不要手写）

`research_team` **不是你填的字段**：deliver 阶段会先跑 `scripts/enrich_team.py`，只对已通过复核的论文按 DOI 回查并原地写回，你写了也会被覆盖。**不要照 `authors` 猜谁是通讯作者**，也不要为了"看起来完整"自己补。

三级回退，措辞与「是不是事实」严格对应——区别在于**缺的是标记还是整条记录**：

| source | confidence | 缺什么 | 报告呈现 |
|---|---|---|---|
| `openalex_corresponding` | high | 什么都不缺，OpenAlex 明确标记 | 姓名（一级单位，国家） |
| `inferred_last_author` | low | 缺"谁牵头"的标记，但作者与机构齐全 | **末三位作者**（各带单位）+ ⚠ 低置信度 |
| `fallback_tail_authors` | unverified | 连 OpenAlex 记录都没有 | 只有名单末三位 + ⚠ 待核实：无机构信息 |
| `unavailable` | unverified | 各数据源都没有作者信息 | 未获取到 |

- **推断级为何给三位而不是一位（2026-09-16 用户裁定）**：OpenAlex 官方实测「末位作者=负责人」的假设近半出错，只给一个人等于把这个不靠谱的假设当唯一答案呈现；给末三位并标注低置信度，判断权仍在读者手里。
- **政府部门误解析防护（2026-09-16 实测驱动）**：OpenAlex 会把作者单位误解析成政府部门——实测一篇复旦团队的 Nature Communications 论文，**全部 9 位作者**的单位被解析成 `Ministry of Education`（韩国教育部），顶层是 `Government of the Republic of Korea`。命中「Ministry of / Government of」这类模式时，**机构与国家一律不显示**，只留姓名并标「机构待核实」。**注意不能用 `type == "government"` 判定**——中科院、NIH、国家自然科学基金委在 OpenAlex 里都是 `government`，那条规则会大面积误伤。

- 报告里的标题恒为「**研究团队**」，不写「通讯作者」：后两级往往并不真是通讯作者，写成通讯作者等于把猜测包装成事实。
- 机构只到**一级单位**（"中山大学"而非"中山大学药学院"）；国别用**中文**（二字码对少见国家不可读）。
- **不做** JATS/PMC 全文与出版社页面解析：2026-09-16 实测 39 篇交叉表里「OpenAlex 缺失而 JATS 可得」= 0%，维护收益为零的通道不划算。

## 去重与研究记忆

`data/pushed_articles.json` 是交付历史。论文身份优先使用 DOI，没有 DOI 时使用规范化题名。已经推送的 DOI 不能再次作为新论文推送。预印本转为正式出版时标记为“更新”，不能当成全新论文。所有写入操作必须保持原子性。

`data/research_memory.json` 只记录已经确认交付的报告，包括精简结论、标签、已解释术语、研究路线关联、强烈推荐、未解决验证事项和研究思路。修改记忆行为时阅读 [`references/research_memory.md`](references/research_memory.md)。这是本地工作流记忆，不是模型训练。

## 通知与错误处理

通知渠道优先级为 WxPusher、Server酱、企业微信。凭据只能存放在环境变量中，不得出现在报告或日志里：

- WxPusher：`WXPUSHER_APP_TOKEN`、`WXPUSHER_UID`；可选 `WXPUSHER_CONTENT_URL`。
- Server酱：`SERVERCHAN_SENDKEY`。
- 企业微信：`WECOM_WEBHOOK_URL` 或 `WECHAT_WORK_WEBHOOK_URL`。

配置、测试或排查 WxPusher 时阅读 [`references/wxpusher_setup.md`](references/wxpusher_setup.md)。使用 `python scripts/push_wechat.py --provider wxpusher --check-config` 在本地检查配置；只有得到明确授权后，才可使用 `--test-message` 发送真实测试消息。

没有配置通知渠道时仍要正常生成报告，并准确提示：“微信推送尚未配置。”某一个文献来源失败时继续处理其他来源，并说明失败情况；所有来源都失败时停止。没有论文通过复核时生成零推荐报告，不能降低阈值。不得无限重试。

仓库不预设周期任务。只有用户明确要求时才创建或修改定时任务，并在定时提示词中写明自动交付授权。

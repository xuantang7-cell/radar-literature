#!/usr/bin/env python3
"""从稳定的公开学术接口检索近期论文并规范化元数据。"""

from __future__ import annotations

import argparse
import os
import re
import sys
import time
from collections.abc import Callable
from datetime import date, datetime, timedelta
from typing import Any
from urllib.error import HTTPError
from urllib.parse import urlencode

from common import (
    ChineseArgumentParser,
    atomic_write_json,
    clean_text,
    date_from_parts,
    deduplicate_papers,
    first_nonempty,
    json_request,
    load_dotenv_if_present,
    normalize_doi,
    parse_date,
    quota_exhausted,
    quota_snapshot,
    unique_strings,
    utc_now_iso,
)
from profile_config import DEFAULT_PROFILE, ProfileError, load_profile, profile_queries, profile_terms

API_SOURCES = ("europepmc", "crossref", "semanticscholar", "openalex", "biorxiv")

# 默认只用三源，其余两源可手动指定但不进默认流程：
#   - biorxiv 只出预印本，而白名单 41 本全是正式期刊，命中后必然被 gate 剔除；
#   - semanticscholar 在无 API Key 时限流严重（实测 HTTP 429 直接失败），
#     且它覆盖的记录大多已由 Europe PMC / Crossref 提供。
# 选择三源并集的理由不是覆盖率好看：Europe PMC 对 ACS / Wiley / RSC 系
# 出版商的元数据更新滞后（实测 ACS Nano 滞后 34 天、Nano Research 277 天），
# 单源会让推荐系统性偏向 JCR、Biomaterials 等少数几本刊。
DEFAULT_SOURCES = ("europepmc", "crossref", "openalex")

OPENALEX_SELECT_FIELDS = (
    "id",
    "doi",
    "display_name",
    "authorships",
    "primary_location",
    "publication_date",
    "type",
    "abstract_inverted_index",
    "cited_by_count",
    "open_access",
    "best_oa_location",
    "is_retracted",
)
OPENALEX_MAX_RESULTS_PER_QUERY = 600

# 限流熔断阈值：连续多少个查询词都被 429/503 挡下就停止该源。
# 原先没有熔断——首个查询词被限流后，异常直接上抛到 collect()，
# 导致该源**已收集到的结果一并丢弃**，计数归 0（"暂时限流"→"整源归零"）。
# 熔断后改为返回部分结果，至少保住限流发生前抓到的论文。
OPENALEX_RATE_LIMIT_CIRCUIT_BREAKER = 2


def compact_query(query: str) -> str:
    """为不支持布尔语法的接口生成普通查询文本。"""
    text = re.sub(r"\b(?:AND|OR|NOT)\b", " ", query, flags=re.IGNORECASE)
    text = text.replace("(", " ").replace(")", " ").replace('"', "")
    return re.sub(r"\s+", " ", text).strip()


def plausible_relevance(paper: dict[str, Any], terms: list[str]) -> bool:
    text = f"{paper.get('title', '')} {paper.get('abstract', '')}".casefold()
    return any(term.casefold() in text for term in terms)


def _epmc_type(record: dict[str, Any]) -> str:
    values = record.get("pubTypeList", {}).get("pubType", [])
    if isinstance(values, str):
        return values
    return "; ".join(clean_text(value) for value in values if value)


# 单页取 500 条时 Europe PMC 的响应体会超过 3 MB，在部分网络环境下必然
# IncompleteRead。实测 pageSize=100 仍会因「本页摘要恰好较长」波动到 1.3 MB，
# 超出校园网稳定传输阈值（约 1 MB 上下），依然偶发截断。pageSize=50 实测
# 约 245 KB，余量充足且稳定。配合 cursorMark 游标分页，总量不减、单次请求小。
# 该接口不支持 gzip（实测忽略 Accept-Encoding），只能靠减小单页体积解决。
EPMC_PAGE_SIZE = 50
EPMC_MAX_RESULTS = 2000


def search_europepmc(queries: list[str], start: date, end: date) -> list[dict[str, Any]]:
    combined = " OR ".join(f"({query})" for query in queries)
    epmc_query = f"({combined}) AND FIRST_PDATE:[{start.isoformat()} TO {end.isoformat()}] sort_date:y"
    output: list[dict[str, Any]] = []
    cursor = "*"
    seen_cursors: set[str] = set()
    while cursor and cursor not in seen_cursors and len(output) < EPMC_MAX_RESULTS:
        seen_cursors.add(cursor)
        params = urlencode(
            {
                "query": epmc_query,
                "format": "json",
                "resultType": "core",
                "pageSize": EPMC_PAGE_SIZE,
                "cursorMark": cursor,
                "synonym": "false",
            }
        )
        payload = json_request(f"https://www.ebi.ac.uk/europepmc/webservices/rest/search?{params}")
        records = payload.get("resultList", {}).get("result", [])
        for item in records:
            doi = normalize_doi(item.get("doi"))
            pmid = clean_text(item.get("pmid"))
            pmcid = clean_text(item.get("pmcid"))
            url = f"https://doi.org/{doi}" if doi else (
                f"https://europepmc.org/article/MED/{pmid}" if pmid else f"https://europepmc.org/article/PMC/{pmcid}"
            )
            output.append(
                {
                    "doi": doi,
                    "title": clean_text(item.get("title")),
                    "authors": unique_strings((item.get("authorString") or "").split(",")),
                    "journal": clean_text(first_nonempty(item.get("journalTitle"), item.get("journalInfo", {}).get("journal", {}).get("title"))),
                    "publication_date": parse_date(first_nonempty(item.get("firstPublicationDate"), item.get("electronicPublicationDate"), item.get("journalInfo", {}).get("printPublicationDate"))),
                    "url": url,
                    "article_type": _epmc_type(item),
                    "abstract": clean_text(item.get("abstractText")),
                    "sources": ["Europe PMC"],
                    "source_ids": {key: value for key, value in {"pmid": pmid, "pmcid": pmcid}.items() if value},
                    "citation_count": int(item.get("citedByCount") or 0),
                    "is_open_access": str(item.get("isOpenAccess", "")).upper() == "Y",
                    "is_preprint": "preprint" in _epmc_type(item).casefold(),
                    "needs_verification": [] if item.get("abstractText") else ["摘要缺失，核心结论需从原文核实"],
                }
            )
        next_cursor = clean_text(payload.get("nextCursorMark"))
        if not records or not next_cursor or next_cursor in seen_cursors:
            break
        cursor = next_cursor
        time.sleep(0.15)
    return output


def _crossref_date(item: dict[str, Any]) -> str:
    for key in ("published-online", "published", "issued", "published-print", "created"):
        value = item.get(key)
        if key == "created" and isinstance(value, dict) and value.get("date-time"):
            parsed = parse_date(value.get("date-time"))
        else:
            parsed = date_from_parts(value) if value else ""
        if parsed:
            return parsed
    return ""


def search_crossref(queries: list[str], start: date, end: date) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    mailto = os.environ.get("CROSSREF_MAILTO", "").strip()
    date_filter_pairs = (
        ("from-online-pub-date", "until-online-pub-date"),
        ("from-pub-date", "until-pub-date"),
    )
    request_total = len(queries) * len(date_filter_pairs)
    request_index = 0
    for query in queries:
        for from_filter, until_filter in date_filter_pairs:
            params: dict[str, Any] = {
                "query.bibliographic": compact_query(query),
                "filter": (
                    f"{from_filter}:{start.isoformat()},"
                    f"{until_filter}:{end.isoformat()},"
                    "type:journal-article"
                ),
                "rows": 100,
                "sort": "published",
                "order": "desc",
            }
            if mailto:
                params["mailto"] = mailto
            payload = json_request(f"https://api.crossref.org/works?{urlencode(params)}")
            for item in payload.get("message", {}).get("items", []):
                authors = []
                for author in item.get("author", []):
                    name = " ".join(
                        filter(
                            None,
                            [
                                clean_text(author.get("given")),
                                clean_text(author.get("family")),
                            ],
                        )
                    )
                    if name:
                        authors.append(name)
                doi = normalize_doi(item.get("DOI"))
                output.append(
                    {
                        "doi": doi,
                        "title": clean_text(first_nonempty(*(item.get("title") or []))),
                        "authors": unique_strings(authors),
                        "journal": clean_text(first_nonempty(*(item.get("container-title") or []))),
                        "publication_date": _crossref_date(item),
                        "url": clean_text(
                            first_nonempty(
                                item.get("URL"), f"https://doi.org/{doi}" if doi else ""
                            )
                        ),
                        "article_type": clean_text(item.get("type")),
                        "abstract": clean_text(item.get("abstract")),
                        "sources": ["Crossref"],
                        "source_ids": {},
                        "citation_count": int(item.get("is-referenced-by-count") or 0),
                        "is_open_access": bool(item.get("license")),
                        "is_preprint": item.get("type") == "posted-content",
                        "needs_verification": (
                            []
                            if item.get("abstract")
                            else ["Crossref 未提供摘要，结论需从原文核实"]
                        ),
                    }
                )
            request_index += 1
            if request_index < request_total:
                time.sleep(0.15)
    return output


def search_semantic_scholar(queries: list[str], start: date, end: date) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    headers: dict[str, str] = {}
    api_key = os.environ.get("SEMANTIC_SCHOLAR_API_KEY", "").strip()
    if api_key:
        headers["x-api-key"] = api_key
    fields = "title,abstract,authors,venue,publicationDate,url,externalIds,publicationTypes,citationCount,openAccessPdf,journal"
    for index, query in enumerate(queries):
        params = urlencode(
            {
                "query": compact_query(query),
                "limit": 100,
                "fields": fields,
                "year": f"{start.year}-{end.year}",
            }
        )
        payload = json_request(
            f"https://api.semanticscholar.org/graph/v1/paper/search?{params}", headers=headers
        )
        for item in payload.get("data", []):
            published = parse_date(item.get("publicationDate"))
            if not published or not (start.isoformat() <= published <= end.isoformat()):
                continue
            external = item.get("externalIds") or {}
            doi = normalize_doi(external.get("DOI"))
            journal = item.get("journal") or {}
            types = item.get("publicationTypes") or []
            output.append(
                {
                    "doi": doi,
                    "title": clean_text(item.get("title")),
                    "authors": unique_strings(author.get("name") for author in item.get("authors", [])),
                    "journal": clean_text(first_nonempty(journal.get("name"), item.get("venue"))),
                    "publication_date": published,
                    "url": clean_text(first_nonempty(item.get("url"), f"https://doi.org/{doi}" if doi else "")),
                    "article_type": "; ".join(clean_text(value) for value in types),
                    "abstract": clean_text(item.get("abstract")),
                    "sources": ["Semantic Scholar"],
                    "source_ids": {"semantic_scholar": clean_text(item.get("paperId"))},
                    "citation_count": int(item.get("citationCount") or 0),
                    "is_open_access": bool(item.get("openAccessPdf")),
                    "is_preprint": any("preprint" in str(value).casefold() for value in types),
                    "needs_verification": [] if item.get("abstract") else ["Semantic Scholar 未提供摘要，结论需从原文核实"],
                }
            )
        if index + 1 < len(queries):
            # 官方给 API Key 的初始限额为每秒 1 次；匿名请求还会共享公共额度。
            time.sleep(1.05)
    return output


def reconstruct_openalex_abstract(index: Any) -> str:
    """把 OpenAlex 的单词位置倒排索引还原为可读摘要。"""
    if not isinstance(index, dict):
        return ""
    positioned_words: list[tuple[int, str]] = []
    for word, positions in index.items():
        if not isinstance(positions, list):
            continue
        for position in positions:
            if isinstance(position, int) and position >= 0:
                positioned_words.append((position, clean_text(word)))
    positioned_words.sort(key=lambda item: item[0])
    return clean_text(" ".join(word for _, word in positioned_words if word))


def resolve_openalex_mailto() -> str:
    """解析 OpenAlex 礼貌池邮箱。

    优先级：
      1. 环境变量 OPENALEX_MAILTO（在宿主 shell 中设置）；
      2. 共享文件 ~/.workbuddy/openalex_mailto.txt（用户级，任意项目可读）；
      3. 技能本地文件 <skill>/config/openalex_mailto.txt。

    WorkBuddy 的 Bash 沙箱不透传 OS 用户级环境变量，因此文件回退能让
    礼貌池在任意会话 / 项目中稳定生效，无需手动配置环境变量。
    """
    env_val = os.environ.get("OPENALEX_MAILTO", "").strip()
    if env_val:
        return env_val
    candidates = [
        os.path.join(os.path.expanduser("~"), ".workbuddy", "openalex_mailto.txt"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config", "openalex_mailto.txt"),
    ]
    for path in candidates:
        try:
            if os.path.isfile(path):
                with open(path, encoding="utf-8") as fh:
                    value = fh.read().strip()
                if value:
                    return value
        except OSError:
            continue
    return ""


def format_openalex_quota(snapshot: dict[str, int]) -> str:
    """把 OpenAlex 额度快照格式化成一行可读文本（字段缺失就不写，不编造）。"""
    parts: list[str] = []
    remaining = snapshot.get("X-RateLimit-Remaining")
    limit = snapshot.get("X-RateLimit-Limit")
    if remaining is not None:
        parts.append(f"剩余 {remaining}/{limit}" if limit is not None else f"剩余 {remaining}")
    elif limit is not None:
        parts.append(f"上限 {limit}")
    reset = snapshot.get("X-RateLimit-Reset")
    if reset is not None:
        parts.append(f"约 {reset / 3600:.1f} 小时后重置")
    return "，".join(parts)


def format_openalex_usage(
    requests_made: int, credits_used: int, quota: dict[str, int]
) -> str:
    """OpenAlex 本次运行的消耗与余额摘要（用于日志收尾与两条止损分支）。"""
    text = f"[openalex] 本次共 {requests_made} 次请求"
    if credits_used:
        text += f"、计入 {credits_used} credits"
    if quota:
        text += f"；当前额度 {format_openalex_quota(quota)}"
    return text + "。"


def search_openalex(queries: list[str], start: date, end: date) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    headers: dict[str, str] = {}
    api_key = os.environ.get("OPENALEX_API_KEY", "").strip()
    mailto = resolve_openalex_mailto()
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    # 礼貌池诊断：不回显邮箱本身，只说明是否生效。
    # 未进礼貌池时共享出口 IP 一旦拥塞就最先被限流，这条输出用于定位该类失败。
    if mailto:
        print("[openalex] 礼貌池已启用（OPENALEX_MAILTO 已解析到，不回显值）。")
    else:
        print(
            "[openalex] 警告：未解析到 OPENALEX_MAILTO，本次请求不在礼貌池，"
            "共享 IP 拥塞时极易被限流（HTTP 429）。"
        )
    # 额度诊断（2026-09-11 新增）。429 有两种成因完全不同的情况，区分它们是定位的前提：
    #   无 Key —— 实测 1000 credits/天，且**按出口 IP 共享**：同一出口 IP 上的
    #            任何人（含云端沙箱邻居）消耗都会直接挤占本雷达的预算。而雷达
    #            单次运行最坏 14 词 × 6 页 × 10 credits = 840 credits，占 84%，
    #            所以"经常 429"是算术结果，不是网络抽风。
    #   有 Key —— 官方口径为 10× 额度且按账号计，与出口 IP 上的其他人无关。
    # 这也解释了为什么 v11/v12 的"加长退避"治不了它：病根在额度，不在重试耐心。
    if api_key:
        print(
            "[openalex] 已启用 API Key：额度按账号计（不受同出口 IP 他人消耗影响），"
            "官方口径为无 Key 额度的 10 倍。"
        )
    else:
        print(
            "[openalex] 警告：未配置 OPENALEX_API_KEY，本次走匿名额度"
            "（实测 1000 credits/天且按出口 IP 共享），极易被同 IP 他人挤占；"
            "建议在 .env 里配一个免费 Key。"
        )
    consecutive_rate_limited = 0
    quota: dict[str, int] = {}
    requests_made = 0
    credits_used = 0
    for query_index, query in enumerate(queries):
        cursor = "*"
        retrieved_for_query = 0
        seen_cursors: set[str] = set()
        while cursor and retrieved_for_query < OPENALEX_MAX_RESULTS_PER_QUERY:
            if cursor in seen_cursors:
                break
            seen_cursors.add(cursor)
            request_params: dict[str, Any] = {
                "search": query,
                "filter": (
                    f"from_publication_date:{start.isoformat()},"
                    f"to_publication_date:{end.isoformat()},"
                    "primary_location.source.type:journal"
                ),
                "sort": "publication_date:desc",
                "per_page": 100,
                "cursor": cursor,
                "select": ",".join(OPENALEX_SELECT_FIELDS),
            }
            if mailto:
                request_params["mailto"] = mailto
            params = urlencode(request_params)
            response_headers: dict[str, str] = {}
            try:
                payload = json_request(
                    f"https://api.openalex.org/works?{params}",
                    headers=headers,
                    headers_out=response_headers,
                )
            except HTTPError as exc:
                if exc.code not in (429, 503):
                    raise
                # 先读额度头再决定处置：同样是 429，「当日预算见底」与「瞬时拥塞」
                # 的成因与处置完全不同，混为一谈就会把额度问题误报成网络抽风。
                quota.update(quota_snapshot(getattr(exc, "headers", None)))
                if quota_exhausted(exc):
                    print(
                        f"[openalex] 额度耗尽（{format_openalex_quota(quota) or '剩余 0'}）："
                        "当日预算已见底，退避重试无意义（额度在 UTC 00:00 重置），"
                        f"立即停止该源；保留已收集的 {len(output)} 条结果。"
                    )
                    print(format_openalex_usage(requests_made, credits_used, quota))
                    return output
                consecutive_rate_limited += 1
                if consecutive_rate_limited >= OPENALEX_RATE_LIMIT_CIRCUIT_BREAKER:
                    print(
                        f"[openalex] 熔断：连续 {consecutive_rate_limited} 个查询词被限流"
                        f"（HTTP {exc.code}），停止该源；保留已收集的 {len(output)} 条结果。"
                    )
                    print(format_openalex_usage(requests_made, credits_used, quota))
                    return output
                print(
                    f"[openalex] 查询词 {query_index + 1}/{len(queries)} 被限流"
                    f"（HTTP {exc.code}），额度尚有余量"
                    f"（{format_openalex_quota(quota) or '未返回额度头'}）：按瞬时拥塞处理，"
                    "退避后继续。"
                )
                break
            consecutive_rate_limited = 0
            requests_made += 1
            snapshot = quota_snapshot(response_headers)
            quota.update(snapshot)
            credits_used += snapshot.get("X-RateLimit-Credits-Used", 0)
            records = payload.get("results") or []
            remaining = OPENALEX_MAX_RESULTS_PER_QUERY - retrieved_for_query
            records = records[:remaining]
            for item in records:
                doi = normalize_doi(item.get("doi"))
                openalex_url = clean_text(item.get("id"))
                openalex_id = openalex_url.rsplit("/", 1)[-1] if openalex_url else ""
                primary_location = item.get("primary_location") or {}
                best_oa_location = item.get("best_oa_location") or {}
                source = primary_location.get("source") or {}
                abstract = reconstruct_openalex_abstract(item.get("abstract_inverted_index"))
                work_type = clean_text(item.get("type"))
                article_type = (
                    f"retraction; {work_type}" if item.get("is_retracted") else work_type
                )
                landing_page = clean_text(
                    first_nonempty(
                        best_oa_location.get("landing_page_url"),
                        primary_location.get("landing_page_url"),
                        openalex_url,
                    )
                )
                output.append(
                    {
                        "doi": doi,
                        "title": clean_text(item.get("display_name")),
                        "authors": unique_strings(
                            (authorship.get("author") or {}).get("display_name")
                            for authorship in item.get("authorships") or []
                            if isinstance(authorship, dict)
                        ),
                        "journal": clean_text(
                            first_nonempty(
                                source.get("display_name"),
                                primary_location.get("raw_source_name"),
                            )
                        ),
                        "publication_date": parse_date(item.get("publication_date")),
                        "url": f"https://doi.org/{doi}" if doi else landing_page,
                        "article_type": article_type,
                        "abstract": abstract,
                        "sources": ["OpenAlex"],
                        "source_ids": {"openalex": openalex_id} if openalex_id else {},
                        "citation_count": int(item.get("cited_by_count") or 0),
                        "is_open_access": bool(
                            (item.get("open_access") or {}).get("is_oa")
                        ),
                        "is_preprint": work_type.casefold() == "preprint",
                        "needs_verification": (
                            [] if abstract else ["OpenAlex 未提供摘要，结论需从原文核实"]
                        ),
                    }
                )
            retrieved_for_query += len(records)
            next_cursor = clean_text((payload.get("meta") or {}).get("next_cursor"))
            if not records or not next_cursor or next_cursor in seen_cursors:
                break
            cursor = next_cursor
            time.sleep(0.15)
        if query_index + 1 < len(queries):
            time.sleep(0.15)
    # 预算自诊断收尾：把本次消耗与当前余额写进日志（两条提前止损分支也已各打一条）。
    # 没有这一行，下次额度问题又要从「某源 0 条」重新查起。
    print(format_openalex_usage(requests_made, credits_used, quota))
    return output


def search_biorxiv(_queries: list[str], start: date, end: date) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    cursor = 0
    maximum = 600
    while cursor < maximum:
        url = (
            "https://api.biorxiv.org/details/biorxiv/"
            f"{start.isoformat()}/{end.isoformat()}/{cursor}/json"
        )
        payload = json_request(url)
        collection = payload.get("collection", [])
        if not collection:
            break
        for item in collection:
            doi = normalize_doi(item.get("doi"))
            published_doi = normalize_doi(item.get("published"))
            output.append(
                {
                    "doi": doi,
                    "title": clean_text(item.get("title")),
                    "authors": unique_strings((item.get("authors") or "").split(";")),
                    "journal": "bioRxiv",
                    "publication_date": parse_date(item.get("date")),
                    "url": f"https://doi.org/{doi}" if doi else "",
                    "article_type": clean_text(first_nonempty(item.get("type"), "preprint")),
                    "abstract": clean_text(item.get("abstract")),
                    "sources": ["bioRxiv"],
                    "source_ids": {"biorxiv_version": clean_text(item.get("version"))},
                    "citation_count": 0,
                    "is_open_access": True,
                    "is_preprint": True,
                    "formally_published_doi": published_doi,
                    "needs_verification": ["预印本，尚未完成正式同行评议"],
                }
            )
        cursor += len(collection)
        messages = payload.get("messages") or []
        total = int(messages[0].get("total") or cursor) if messages else cursor
        if cursor >= total:
            break
    return output


SOURCE_FUNCTIONS: dict[str, Callable[[list[str], date, date], list[dict[str, Any]]]] = {
    "europepmc": search_europepmc,
    "crossref": search_crossref,
    "semanticscholar": search_semantic_scholar,
    "openalex": search_openalex,
    "biorxiv": search_biorxiv,
}


def collect(
    *,
    queries: list[str],
    start: date,
    end: date,
    sources: list[str],
    relevance_terms: list[str],
) -> dict[str, Any]:
    papers: list[dict[str, Any]] = []
    counts: dict[str, int] = {}
    errors: list[dict[str, str]] = []
    for source in sources:
        # 整源级重试（2026-09-13 v15 修复，针对 Crossref TLS EOF）：
        # 单请求内 3 次退避（json_request）对瞬时 TLS 抖动可能仍不够；
        # 整源失败后等 30 秒（典型 TLS 抖动恢复窗口）再跑一次整源，给瞬时网络故障留活路。
        # 持久故障仍会被两次失败捕获，不影响健康源。
        found = None
        last_exc: Exception | None = None
        for attempt in range(2):  # 0=首次, 1=整源重试
            if attempt > 0:
                time.sleep(30)
            try:
                found = SOURCE_FUNCTIONS[source](queries, start, end)
                last_exc = None
                break
            # 各来源可能出现不同的解析或传输异常；逐个隔离，避免单一来源故障清空其他有效结果。
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
        if found is not None:
            counts[source] = len(found)
            papers.extend(found)
        else:
            counts[source] = 0
            errors.append({"source": source, "error": f"{type(last_exc).__name__}: {last_exc}"})
    retrieved_count = len(papers)
    merged = [
        paper for paper in deduplicate_papers(papers)
        if plausible_relevance(paper, relevance_terms)
    ]
    merged.sort(key=lambda item: (item.get("publication_date", ""), item.get("title", "")), reverse=True)
    return {
        "generated_at": utc_now_iso(),
        "date_from": start.isoformat(),
        "date_to": end.isoformat(),
        "date_precision_note": "部分来源仅提供日级出版日期；默认 1 天窗口是最近 24 小时的近似实现。",
        "queries": queries,
        "sources_requested": sources,
        "source_counts": counts,
        "retrieved_count": retrieved_count,
        "unique_relevant_count": len(merged),
        "errors": errors,
        "papers": merged,
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = ChineseArgumentParser(description=__doc__)
    parser.add_argument("--days", type=int, default=1, choices=range(1, 31), metavar="1-30")
    parser.add_argument("--from-date", help="起始日期 YYYY-MM-DD；设置后覆盖 --days")
    parser.add_argument("--to-date", help="结束日期 YYYY-MM-DD；默认为本地日期的今天")
    parser.add_argument("--mode", default="all", help="研究配置中定义的模式名称")
    parser.add_argument("--query", action="append", help="自定义查询语句；可以重复传入")
    parser.add_argument("--profile", default=str(DEFAULT_PROFILE))
    parser.add_argument("--sources", default=",".join(DEFAULT_SOURCES), help="以英文逗号分隔的来源标识")
    parser.add_argument("--output", required=True, help="输出 JSON 路径")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    _loaded_env = load_dotenv_if_present()
    if _loaded_env:
        print(f"[env] 已从 .env 补载：{', '.join(_loaded_env)}（值不回显）")
    args = parse_args(argv)
    try:
        profile = load_profile(args.profile)
        queries = unique_strings(args.query or profile_queries(profile, args.mode))
        relevance_terms = profile_terms(profile)
    except ProfileError as exc:
        raise SystemExit(str(exc)) from exc
    if not queries:
        raise SystemExit(f"模式“{args.mode}”没有配置查询语句")
    end = date.fromisoformat(args.to_date) if args.to_date else datetime.now().astimezone().date()
    start = date.fromisoformat(args.from_date) if args.from_date else end - timedelta(days=args.days - 1)
    if start > end:
        raise SystemExit("--from-date 不能晚于 --to-date")
    sources = [value.strip().casefold() for value in args.sources.split(",") if value.strip()]
    unknown = [source for source in sources if source not in SOURCE_FUNCTIONS]
    if unknown:
        raise SystemExit(f"未知的文献来源：{', '.join(unknown)}")
    result = collect(
        queries=queries,
        start=start,
        end=end,
        sources=sources,
        relevance_terms=relevance_terms,
    )
    result["mode"] = args.mode
    result["profile_name"] = clean_text(profile.get("profile_name"))
    atomic_write_json(args.output, result)
    print(
        f"共检索 {result['retrieved_count']} 条记录；去重并进行相关性预筛后保留 "
        f"{result['unique_relevant_count']} 篇论文。"
    )
    if result["errors"]:
        print(f"警告：{len(result['errors'])} 个来源检索失败；详情见输出 JSON。", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""科研文献雷达共用的零依赖辅助函数。"""

from __future__ import annotations

import gzip
import http.client
import zlib
import argparse
import hashlib
import html
import json
import os
import random
import re
import tempfile
import time
import sys
from collections.abc import Iterable
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

USER_AGENT = "research-paper-daily-push/1.0 (literature metadata client)"


class ChineseArgumentParser(argparse.ArgumentParser):
    """使用中文标题、帮助说明和错误前缀的命令行参数解析器。"""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        kwargs["add_help"] = False
        super().__init__(*args, **kwargs)
        self._positionals.title = "位置参数"
        self._optionals.title = "选项"
        self.add_argument(
            "-h",
            "--help",
            action="help",
            default=argparse.SUPPRESS,
            help="显示此帮助信息并退出",
        )

    def format_usage(self) -> str:
        return super().format_usage().replace("usage:", "用法：", 1)

    def format_help(self) -> str:
        return super().format_help().replace("usage:", "用法：", 1)

    def error(self, message: str) -> None:
        translations = {
            "the following arguments are required:": "缺少必填参数：",
            "unrecognized arguments:": "无法识别的参数：",
            "expected one argument": "需要一个参数值",
        }
        for source, target in translations.items():
            message = message.replace(source, target)
        self.print_usage(sys.stderr)
        self.exit(2, f"{self.prog}：错误：{message}\n")


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def load_json(path: str | Path, default: Any = None) -> Any:
    target = Path(path)
    if not target.exists():
        return default
    with target.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def atomic_write_json(path: str | Path, payload: Any) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent)
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, target)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def normalize_doi(value: Any) -> str:
    if not value:
        return ""
    doi = str(value).strip().lower()
    doi = re.sub(r"^https?://(?:dx\.)?doi\.org/", "", doi)
    doi = re.sub(r"^doi:\s*", "", doi)
    return doi.rstrip(" .;,)")


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    text = html.unescape(str(value))
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def normalize_title(value: Any) -> str:
    text = clean_text(value).casefold()
    text = re.sub(r"[^\w\u4e00-\u9fff]+", "", text, flags=re.UNICODE)
    return text


def paper_key(paper: dict[str, Any]) -> str:
    doi = normalize_doi(paper.get("doi"))
    if doi:
        return f"doi:{doi}"
    title = normalize_title(paper.get("title"))
    if title:
        return f"title:{hashlib.sha256(title.encode('utf-8')).hexdigest()[:24]}"
    source_ids = paper.get("source_ids") or {}
    stable = json.dumps(source_ids, ensure_ascii=False, sort_keys=True)
    return f"source:{hashlib.sha256(stable.encode('utf-8')).hexdigest()[:24]}"


def first_nonempty(*values: Any) -> Any:
    for value in values:
        if value not in (None, "", [], {}):
            return value
    return ""


def parse_date(value: Any) -> str:
    """尽可能返回 YYYY-MM-DD，无法解析时返回空字符串。"""
    if not value:
        return ""
    if isinstance(value, date):
        return value.isoformat()
    text = str(value).strip()
    match = re.search(r"(\d{4})[-/](\d{1,2})(?:[-/](\d{1,2}))?", text)
    if match:
        year, month, day = match.groups()
        try:
            return date(int(year), int(month), int(day or 1)).isoformat()
        except ValueError:
            return ""
    if re.fullmatch(r"\d{4}", text):
        return f"{text}-01-01"
    return ""


def date_from_parts(parts: Any) -> str:
    try:
        values = list(parts[0]["date-parts"] if isinstance(parts, list) else parts["date-parts"])
        values = list(values[0]) if values and isinstance(values[0], list) else values
        year = int(values[0])
        month = int(values[1]) if len(values) > 1 else 1
        day = int(values[2]) if len(values) > 2 else 1
        return date(year, month, day).isoformat()
    except (KeyError, IndexError, TypeError, ValueError):
        return ""


def _decode_body(raw: bytes, response: Any) -> str:
    """按 Content-Encoding 解压响应体后再解码。

    urllib 不会自动处理 gzip/deflate，声明了 Accept-Encoding 就必须自己解。
    deflate 有两种互不兼容的封装（zlib 头 / 裸流），两种都试一遍。
    """
    encoding = (response.headers.get("Content-Encoding") or "").strip().casefold()
    for name in (part.strip() for part in encoding.split(",") if part.strip()):
        if name == "gzip":
            raw = gzip.decompress(raw)
        elif name == "deflate":
            try:
                raw = zlib.decompress(raw)
            except zlib.error:
                raw = zlib.decompress(raw, -zlib.MAX_WBITS)
    charset = response.headers.get_content_charset() or "utf-8"
    return raw.decode(charset, errors="replace")


# 限流类响应（429 / 503）的退避基准时长（秒）。
# 背景：OpenAlex 等数据源的限流窗口常以分钟计，原先的 2**attempt（1s/2s/4s，
# 三次合计约 3 秒）在窗口内几乎必然再次失败，于是"暂时限流"被放大成"整源归零"。
# 改为 5/15/45s 并叠加最多 20% 的抖动，避免多个进程同时重试形成尖峰。
RATE_LIMIT_BACKOFF = (5.0, 15.0, 45.0)

# 服务端瞬时错误（500/502/504）仍用短退避，这类错误通常几百毫秒内自愈。
SERVER_ERROR_BACKOFF = (1.0, 2.0, 4.0)

# 尊重 Retry-After，但上限放宽到 120 秒（原先 10 秒会截断服务端给出的真实等待时长）。
MAX_RETRY_AFTER_SECONDS = 120.0


def rate_limit_delay(exc: Any, attempt: int) -> float:
    """计算限流/服务端错误后的退避时长。"""
    headers = getattr(exc, "headers", None)
    retry_after = headers.get("Retry-After") if headers else None
    if retry_after and str(retry_after).strip().isdigit():
        return min(float(retry_after), MAX_RETRY_AFTER_SECONDS)
    code = getattr(exc, "code", None)
    table = RATE_LIMIT_BACKOFF if code in (429, 503) else SERVER_ERROR_BACKOFF
    base = table[min(attempt, len(table) - 1)]
    return base + random.uniform(0.0, base * 0.2)


# OpenAlex 的额度响应头（2026-09-11 实测确认，官方文档同口径）：
#   X-RateLimit-Limit         当日总额度
#   X-RateLimit-Remaining     当日剩余
#   X-RateLimit-Reset         距重置的秒数（UTC 00:00，即北京 08:00）
#   X-RateLimit-Credits-Used  本次请求消耗的 credits
# 无 API Key 时实测 Limit=1000 credits/天，且**按出口 IP 共享**；带免费 Key 则
# 官方口径为 10× 且按账号计。这两点决定了 429 的两种成因完全不同（见 quota_exhausted）。
OPENALEX_QUOTA_HEADERS = (
    "X-RateLimit-Limit",
    "X-RateLimit-Remaining",
    "X-RateLimit-Reset",
    "X-RateLimit-Credits-Used",
)


def quota_snapshot(headers: Any) -> dict[str, int]:
    """从响应头解析额度快照。

    头缺失或值非数字一律跳过——额度是"有则用、没有就不猜"的辅助信息，
    解析失败绝不能影响主流程。
    """
    snapshot: dict[str, int] = {}
    if not headers:
        return snapshot
    for name in OPENALEX_QUOTA_HEADERS:
        raw = headers.get(name)
        if raw is None:
            continue
        try:
            snapshot[name] = int(str(raw).strip())
        except (TypeError, ValueError):
            continue
    return snapshot


def quota_exhausted(exc_or_headers: Any) -> bool:
    """判断这次 429 是「当日额度耗尽」还是「瞬时拥塞」。

    2026-09-11 实测确诊：OpenAlex 无 Key 额度 1000 credits/天、按出口 IP 共享，
    而雷达单次运行最坏消耗 840 credits（14 词 × 6 页 × 10 credits/次带 search 的调用）。
    额度耗尽时 429 的重置点是 UTC 00:00，最坏要等约 16 小时——此时 5s/15s/45s 的
    退避重试等价于没等（覆盖所需等待的 0.08%），只会把"整源 0 条"伪装成"网络抽风"。

    因此：`X-RateLimit-Remaining == 0` 判为额度耗尽 → 立即止损并如实上报；
    只剩 `>0` 的 429 才当拥塞处理，退避重试才有意义。
    """
    headers = getattr(exc_or_headers, "headers", exc_or_headers)
    remaining = quota_snapshot(headers).get("X-RateLimit-Remaining")
    return remaining is not None and remaining <= 0


def load_dotenv_if_present(base_dir: str | None = None) -> list[str]:
    """从 .env 文件补载环境变量（**不覆盖**进程已有的同名变量）。

    各脚本只经 os.environ 读配置，而云端沙箱的 shell 状态不跨命令块保留——
    只在自举那一步 `set -a && . ./.env` 导出过的话，后续 collect/deliver 进程
    就拿不到 OPENALEX_MAILTO 等变量，会静默掉出 OpenAlex 礼貌池，在共享出口 IP
    拥塞时最先被限流。脚本启动时自行补载可彻底消除这一不确定性。

    返回实际补载的键名列表（便于诊断打印，值本身不回显）。
    """
    if base_dir is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    env_path = os.path.join(base_dir, "..", ".env")
    loaded: list[str] = []
    try:
        if not os.path.isfile(env_path):
            return loaded
        with open(env_path, encoding="utf-8") as fh:
            for raw_line in fh:
                line = raw_line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key and key not in os.environ and value:
                    os.environ[key] = value
                    loaded.append(key)
    except OSError:
        return loaded
    return loaded


def json_request(
    url: str,
    *,
    method: str = "GET",
    payload: Any = None,
    headers: dict[str, str] | None = None,
    timeout: int = 30,
    retries: int = 3,
    headers_out: dict[str, str] | None = None,
) -> Any:
    """发起 JSON 请求；`headers_out` 非 None 时回填成功响应的响应头。

    回填响应头是为了让调用方能读到 OpenAlex 的 `X-RateLimit-*` 额度信息
    （预算自诊断）。只在**成功响应**上回填，避免把失败尝试的头混进来。
    """
    request_headers = {
        "Accept": "application/json",
        "User-Agent": USER_AGENT,
        # 大响应体（Europe PMC 单次可超过 3 MB）在弱网下极易传输中断；
        # gzip 可把体积压到十分之一量级，显著降低 IncompleteRead 概率。
        "Accept-Encoding": "gzip, deflate",
    }
    if headers:
        request_headers.update(headers)
    data = None
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        request_headers.setdefault("Content-Type", "application/json; charset=utf-8")

    last_error: Exception | None = None
    for attempt in range(retries):
        try:
            request = Request(url, data=data, headers=request_headers, method=method)
            with urlopen(request, timeout=timeout) as response:
                if headers_out is not None:
                    headers_out.clear()
                    headers_out.update(dict(response.headers))
                return json.loads(_decode_body(response.read(), response))
        except HTTPError as exc:
            last_error = exc
            # 额度耗尽不是瞬时故障：重置点在 UTC 00:00，退避重试必然再撞同一面墙
            # （45s 相对最坏 ~16h 的等待只覆盖 0.08%）。立即上抛，让调用方按
            # "预算见底"如实上报，而不是空等几十秒后把它报成"网络抽风"。
            if quota_exhausted(exc):
                raise
            if exc.code not in {429, 500, 502, 503, 504} or attempt + 1 >= retries:
                raise
            time.sleep(rate_limit_delay(exc, attempt))
        except (
            URLError,
            TimeoutError,
            json.JSONDecodeError,
            # http.client.IncompleteRead 继承自 http.client.HTTPException，
            # 与 urllib 的 URLError 没有继承关系——不显式列出就会穿透重试逻辑，
            # 让整个检索因一次弱网抖动而失败。
            http.client.HTTPException,
            OSError,
        ) as exc:
            last_error = exc
            if attempt + 1 >= retries:
                raise
            time.sleep(2**attempt)
    if last_error:
        raise last_error
    raise RuntimeError("HTTP 请求失败，但没有捕获到具体异常")


def form_request(
    url: str,
    fields: dict[str, str],
    *,
    timeout: int = 30,
    retries: int = 2,
) -> Any:
    from urllib.parse import urlencode

    encoded = urlencode(fields).encode("utf-8")
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
        "User-Agent": USER_AGENT,
    }
    last_error: Exception | None = None
    for attempt in range(retries):
        try:
            request = Request(url, data=encoded, headers=headers, method="POST")
            with urlopen(request, timeout=timeout) as response:
                charset = response.headers.get_content_charset() or "utf-8"
                return json.loads(response.read().decode(charset))
        except (HTTPError, URLError, TimeoutError, json.JSONDecodeError) as exc:
            last_error = exc
            if attempt + 1 >= retries:
                raise
            time.sleep(2**attempt)
    if last_error:
        raise last_error
    raise RuntimeError("表单请求失败，但没有捕获到具体异常")


def extract_papers(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ("papers", "new", "recommendations", "articles"):
        items = payload.get(key)
        if isinstance(items, list):
            return [item for item in items if isinstance(item, dict)]
    return []


def unique_strings(values: Iterable[Any]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        text = clean_text(value)
        marker = text.casefold()
        if text and marker not in seen:
            seen.add(marker)
            result.append(text)
    return result


def merge_papers(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
    merged = dict(left)
    for field in ("doi", "title", "journal", "publication_date", "url", "article_type"):
        merged[field] = first_nonempty(left.get(field), right.get(field))
    left_abstract = clean_text(left.get("abstract"))
    right_abstract = clean_text(right.get("abstract"))
    merged["abstract"] = right_abstract if len(right_abstract) > len(left_abstract) else left_abstract
    merged["authors"] = unique_strings((left.get("authors") or []) + (right.get("authors") or []))
    merged["sources"] = unique_strings((left.get("sources") or []) + (right.get("sources") or []))
    source_ids = dict(left.get("source_ids") or {})
    source_ids.update(right.get("source_ids") or {})
    merged["source_ids"] = source_ids
    merged["citation_count"] = max(int(left.get("citation_count") or 0), int(right.get("citation_count") or 0))
    merged["is_open_access"] = bool(left.get("is_open_access") or right.get("is_open_access"))
    merged["is_preprint"] = bool(left.get("is_preprint") or right.get("is_preprint"))
    merged["needs_verification"] = unique_strings(
        (left.get("needs_verification") or []) + (right.get("needs_verification") or [])
    )
    return merged


def deduplicate_papers(papers: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    by_key: dict[str, dict[str, Any]] = {}
    title_to_key: dict[str, str] = {}
    for paper in papers:
        candidate = dict(paper)
        candidate["doi"] = normalize_doi(candidate.get("doi"))
        candidate["title"] = clean_text(candidate.get("title"))
        candidate["abstract"] = clean_text(candidate.get("abstract"))
        key = paper_key(candidate)
        normalized_title = normalize_title(candidate.get("title"))
        existing_key = key if key in by_key else title_to_key.get(normalized_title, "")
        if existing_key:
            by_key[existing_key] = merge_papers(by_key[existing_key], candidate)
        else:
            by_key[key] = candidate
            if normalized_title:
                title_to_key[normalized_title] = key
    return list(by_key.values())

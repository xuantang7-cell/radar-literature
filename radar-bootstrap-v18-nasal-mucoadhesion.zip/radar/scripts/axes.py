#!/usr/bin/env python3
"""三轴契合度判读（通用引擎）。

从 config 的 `relevance_axes` 读取轴配置（词表 + 档位 + 权重），通用判读：
1 根主轴（primary）+ 0~2 根调制轴（modulators）。

    rel = 100 × P × Π(1 − wᵢ + wᵢ·Mᵢ)

鼻-脑三轴（给药途径 × 疾病 × 制剂形式）只是 `relevance_axes` 的一个填充实例，
全部词表/档位/权重都在配置里，本模块不含任何领域词表。
"""
from __future__ import annotations

from typing import Any


def _hit(text: str, terms: list[str]) -> list[str]:
    """子串命中（刻意不用词边界，词表含词干时词边界会切断词干）。"""
    return [t for t in terms if t in text]


def load_axes_config(profile: dict[str, Any]) -> dict[str, Any] | None:
    """从 profile 读取 relevance_axes；缺失或结构无效返回 None。"""
    cfg = profile.get("relevance_axes")
    if not isinstance(cfg, dict) or not isinstance(cfg.get("primary"), dict):
        return None
    return cfg


def _judge_levels(text: str, levels: list[Any]) -> dict[str, Any] | None:
    """遍历档位（数组顺序 = 优先级从高到低），第一个 terms 命中的档位取胜。"""
    for lv in levels:
        if not isinstance(lv, dict):
            continue
        terms = lv.get("terms") or []
        hits = _hit(text, terms) if terms else []
        if hits:
            return {
                "value": lv.get("value", 0.0),
                "label": lv.get("label", ""),
                "evidence": hits[:3],
                "src": "明写",
            }
    return None


def _judge_axis(text: str, axis_cfg: dict[str, Any]) -> dict[str, Any]:
    """判读单轴：levels 命中 → 明写；否则 fallback_rules 推定；否则 terms 为空的兜底档。"""
    hit = _judge_levels(text, axis_cfg.get("levels") or [])
    if hit:
        return hit
    for rule in axis_cfg.get("fallback_rules") or []:
        if not isinstance(rule, dict):
            continue
        terms = rule.get("terms") or []
        hits = _hit(text, terms) if terms else []
        if hits:
            return {
                "value": rule.get("value", 0.0),
                "label": rule.get("label", ""),
                "evidence": hits[:3],
                "src": "推定",
            }
    # 兜底：terms 为空的最后一档（通常 value 最低，表达「未提及」）
    for lv in reversed(axis_cfg.get("levels") or []):
        if isinstance(lv, dict) and not (lv.get("terms") or []):
            return {
                "value": lv.get("value", 0.0),
                "label": lv.get("label", ""),
                "evidence": [],
                "src": "无",
            }
    return {"value": 0.0, "label": "未判定", "evidence": [], "src": "无"}


def f_rel(P: float, M_values: list[float], weights: list[float] | None = None) -> int:
    """通用 rel 公式：100 × P × Π(1 − wᵢ + wᵢ·Mᵢ)。

    weights=None 时默认 [0.35, 0.20]（鼻-脑标定值，作为「阶段 4 标定前」的起点）。
    """
    if weights is None:
        weights = [0.35, 0.20]
    rel = 100.0 * P
    for m, w in zip(M_values, weights):
        rel *= (1.0 - w + w * m)
    return round(rel)


def axes(
    text: str,
    article_type: str = "",
    axes_cfg: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """通用三轴判读。axes_cfg 为 None（未配置 relevance_axes）时返回 relevance=0。"""
    is_review = "review" in (article_type or "").casefold()
    if not axes_cfg:
        return {"relevance": 0, "primary": None, "modulators": [], "is_review": is_review}
    primary = _judge_axis(text, axes_cfg["primary"])
    modulators = [_judge_axis(text, m) for m in axes_cfg.get("modulators") or []]
    P = primary["value"]
    M_values = [m["value"] for m in modulators]
    weights = [float(m.get("weight", 0.0)) for m in axes_cfg.get("modulators") or []]
    rel = f_rel(P, M_values, weights)
    return {
        "relevance": rel,
        "primary": primary,
        "modulators": modulators,
        "is_review": is_review,
    }

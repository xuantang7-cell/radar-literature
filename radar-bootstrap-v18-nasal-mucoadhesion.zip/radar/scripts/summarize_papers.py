#!/usr/bin/env python3
"""验证 Codex 复核后的论文摘要数据，并生成中文每日报告。"""

from __future__ import annotations

import argparse
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from axes import f_rel
from common import ChineseArgumentParser, clean_text, load_json, normalize_doi

REQUIRED_INSPIRATION = (
    "experimental_design",
    "methods",
    "key_entities_mechanisms",
    "target_system",
    "future_direction",
    "paper_potential",
    "limitations_validation",
)

# ---- 研究启发：三必填 + 四可选（2026-09-16 用户裁定）----
# 背景：七类全部非空才通过校验，于是边缘相关论文也要硬凑七行，注水严重。
# 三项必填分别回答「我能不能照着做 / 能不能变成课题 / 能不能挑毛病」，
# 其余四项大多能被它们覆盖，有则写、无则整行不出现。
CORE_INSPIRATION = (
    "experimental_design",
    "future_direction",
    "limitations_validation",
)
OPTIONAL_INSPIRATION = tuple(f for f in REQUIRED_INSPIRATION if f not in CORE_INSPIRATION)

# ---- 递送主体性（2026-09-07 用户裁定）----
# 复核环节须判定「递送系统在本研究中的地位」并写入 delivery_centrality：
#   core         制剂/递送系统本身是研究核心（载体设计、递送效率、体内分布、
#                屏障穿透、药动学是主要终点）。此类在药剂学语境下稀缺，给排序优势。
#   tool         递送是手段，核心科学问题是疾病治疗/机制验证。这是药剂学主流，
#                不加不减——用户明确：「绝大部分人做的都是类似的研究，真正以制剂
#                为核心的论文太少了，若按 core 之外一律降分，文章数量会太少」。
#   non_delivery 研究中不存在制剂/递送系统这一层，**且其结论也不服务于递送设计**。
#                典型：小分子裸药的药理/机制研究、裸纳米酶/裸纳米簇直接作用于细胞、
#                纯靶点与信号通路研究。本雷达检索药物递送领域论文，此类直接排除。
#                2026-09-08 用户裁定放宽：**构效/转运基础研究即使不载药、不给药、
#                无装置也判 tool，不得判 non_delivery** —— 它揭示的构效与跨屏障转运
#                规律直接服务于载体与处方设计，有工具价值（例：只研究脂质分子如何在
#                多细胞聚集体中迁移 → tool）。判据因此是「有没有制剂层，或结论是否
#                服务于递送设计」，二者皆无才算 non_delivery。
#                注意「制剂」是「药物」的上位概念（2026-09-07 用户裁定）：判定不要求
#                研究里存在药物，只要有剂型/给药装置/工艺这一层（吸入装置、粉体工程、
#                微针、雾化器等）即为递送研究；装置与粉体本身是研究对象时判 core。
DELIVERY_CENTRALITY_VALUES = ("core", "tool", "non_delivery")

# ---- v13 三轴 + 内容评价字段（阶段 4 定稿，代码阶段 5 实现）----
# 三轴 R/F/D 由 AI 读摘要判定；rel = 100×R×(0.65+0.35·D)×(0.80+0.20·F)（见 axes.f_rel）。
# 内容 = 4 项评分（简单平均，不加权）+ 3 项加分（有则加、无则不加）。
# 最终分 = 0.10·rel + 0.20·content + 0.70·qual（5 条锚反推，阶段 3 定稿）。
# novelty/methodology/inspiration 三维已证伪删除（阶段 2 诊断：方法词表命中数的三张映射表）。
R_VALUES = (1.00, 0.40, 0.05)
F_VALUES = (1.00, 0.85, 0.50, 0.00)
D_VALUES = (1.00, 0.70, 0.35, 0.00)
CONTENT_SCORE_FIELDS = ("evidence_chain", "bottleneck", "mechanism_novelty", "structure_activity")
CONTENT_BONUS = {
    "in_vivo_evidence": 5,
    "efficacy_causality": 5,
    "transfer_inspiration": 3,
}
# 引擎内置的通用科研质量评分维度（任何领域都成立，不暴露给用户配置）。
GENERIC_CONTENT_DIMS = ("evidence_chain", "bottleneck", "mechanism_novelty")
W_REL, W_CONTENT, W_QUAL = 0.10, 0.20, 0.70


def load_content_scoring(profile: dict[str, Any]) -> tuple[list[str], dict[str, int]]:
    """从 profile 读 content_scoring；返回 (rating_dims, bonus_dims)。

    未配置 content_scoring 时返回模块级默认（鼻-脑值）。rating_dims =
    引擎内置通用维度 + extra_rating_dims（领域专属评分维度）；bonus_dims =
    领域专属加分项（key -> 加分值）。
    """
    cs = profile.get("content_scoring") if isinstance(profile, dict) else None
    if not isinstance(cs, dict):
        return list(CONTENT_SCORE_FIELDS), dict(CONTENT_BONUS)
    rating_dims = list(GENERIC_CONTENT_DIMS)
    for item in cs.get("extra_rating_dims") or []:
        if isinstance(item, dict) and item.get("key"):
            rating_dims.append(item["key"])
    bonus_dims: dict[str, int] = {}
    for item in cs.get("bonus_dims") or []:
        if isinstance(item, dict) and item.get("key"):
            bonus_dims[item["key"]] = int(item.get("bonus", 0))
    return rating_dims, bonus_dims


def load_axis_values(profile: dict[str, Any]) -> tuple[tuple, tuple, tuple]:
    """从 relevance_axes 读 AI 复核层三轴档位值，返回 (R_VALUES, F_VALUES, D_VALUES)。

    未配置 relevance_axes 时返回模块级默认。映射（鼻-脑 profile 约定）：
    R=primary（给药途径）、D=modulators[0]（疾病）、F=modulators[1]（制剂形式）。
    初筛层与 AI 复核层由此共用同一处档位值定义（单一数据源）。
    """
    axes_cfg = profile.get("relevance_axes") if isinstance(profile, dict) else None
    if not isinstance(axes_cfg, dict) or not isinstance(axes_cfg.get("primary"), dict):
        return R_VALUES, F_VALUES, D_VALUES

    def _values(axis: dict[str, Any]) -> tuple:
        out: list[float] = []
        for lv in (axis.get("levels") or []):
            if isinstance(lv, dict) and "value" in lv:
                v = lv["value"]
                if v not in out:
                    out.append(v)
        return tuple(out)

    primary = axes_cfg["primary"]
    mods = axes_cfg.get("modulators") or []
    r = _values(primary)
    d = _values(mods[0]) if len(mods) >= 1 else ()
    f = _values(mods[1]) if len(mods) >= 2 else ()
    return r, f, d

# ---- 给药途径定性 gate（2026-09-08 用户裁定：先按主题选，再对入选者评分排序）----
# 判定顺序：AI 先给 route_class → 落在 ROUTE_EXCLUDED 的直接定性排除，
# 不进入加权评分、不占用推荐名额；通过者才由 AI 给三维分并参与排序。
# route_class 由阅读理解给出，不得用关键词词表代劳（词表是召回层，不是判定层）。
ROUTE_CLASS_VALUES = ("nasal_brain", "other_cns", "pulmonary", "non_delivery", "out_of_scope")
ROUTE_EXCLUDED = ("non_delivery", "out_of_scope")
ROUTE_CLASS_LABELS = {
    "nasal_brain": "经鼻-脑",
    "other_cns": "其他 CNS 递送",
    "pulmonary": "肺部吸入",
    "non_delivery": "非递送研究",
    "out_of_scope": "主题外",
}
CENTRALITY_LABELS = {"core": "制剂为核心", "tool": "递送为工具", "non_delivery": "非递送"}

# ---- 评分可读化（2026-09-16 用户裁定）----
# 原来 rel（权重 0.10）与 qual（权重 0.70）平铺在同一行，期刊档位名还不显示，
# 于是「期刊 80」是个没有参照的裸数字。补上三轴语义与档位名，数字才有意义。
AXIS_R_LABELS = {1.00: "鼻腔/肺吸入", 0.40: "其他系统·局部", 0.05: "途径未提"}
AXIS_F_LABELS = {1.00: "成型制剂", 0.85: "载体分散体系", 0.50: "仅泛称", 0.00: "无制剂层"}
AXIS_D_LABELS = {1.00: "CNS/呼吸", 0.70: "仅靶向声明", 0.35: "其他疾病", 0.00: "疾病未提"}
JOURNAL_TIER_LABELS = {
    100: "L0 顶刊正刊",
    92: "L1 大子刊/领域旗舰",
    80: "L2 高影响子刊",
    75: "L3 一区强势刊",
    70: "L4 一区常规刊",
}

# 「本期最值得阅读前三名」板块用：内容分的四个维度就是「值得学它什么」的客观依据，
# 不依赖 AI 另写评语，也不会与正文的推荐理由重复。领域专属维度缺标签时退回字段名。
CONTENT_DIM_LABELS = {
    "evidence_chain": "证据链",
    "bottleneck": "真实瓶颈",
    "mechanism_novelty": "机制新颖",
    "structure_activity": "构效可迁移",
}

# 内容维度的**展示与写作顺序**（2026-09-16 用户裁定）：
# 真实瓶颈 → 证据链 → 机制新颖 → 构效可迁移。
# 理由：证据链必须围绕真实瓶颈来评——先确认这篇针对的是哪个明确的需求/瓶颈，
# 再看它的实验是否**真正证明了这个瓶颈被突破**，而不是链条看起来长不长。
# 反例（用户给出）：针对「鼻腔清除限制滞留」开发的鼻腔原位凝胶，若实验只测了
# 相变与黏度增大、没测鼻腔滞留时间，即便有完整的体内药效，也不算证据链完整。
CONTENT_DIM_ORDER = ("bottleneck", "evidence_chain", "mechanism_novelty", "structure_activity")

# content_rationale 防退化下限（字）：低于它说明退化成"针对明确的递送瓶颈"这类
# 万能短语。为什么是结构检查而不是语义打分——与 why_worth_reading 的 W1 同理：
# "自然流畅的句子"无法机械判定语义，但"短语式套话"在长度上必然很短，可机械拦截。
RATIONALE_MIN_CHARS = 15

BONUS_LABELS = {
    "in_vivo_evidence": "体内递送已证实",
    "efficacy_causality": "递送-疗效因果",
    "transfer_inspiration": "迁移启发",
}


def axis_text(article: dict[str, Any]) -> str:
    """把三轴数值还原成人读的定性描述，替代裸露的 rel=100。"""
    parts: list[str] = []
    for key, mapping in (("R", AXIS_R_LABELS), ("D", AXIS_D_LABELS), ("F", AXIS_F_LABELS)):
        value = article.get(key)
        if isinstance(value, (int, float)) and value in mapping:
            parts.append(mapping[value])
    return " · ".join(parts) if parts else "未判定"


def journal_tier_label(qual: int) -> str:
    """期刊档位名（L0–L4）；非标准分值时返回空串，不硬套。"""
    return JOURNAL_TIER_LABELS.get(int(qual), "")

# ---- why_worth_reading 结构契约（2026-09-08 用户裁定 W1）----
# 背景：09-04 已裁定写成「问题 → 策略 → 结果」完整论述并保留价值结论，
# 但校验器只查非空 → 2026-09-08 一轮 8 篇全部退化为 47-60 字的一句话概述
# （历史 research_memory 中位 201 字），而校验全绿放行。规则不可执行等于没有规则。
# W1 只做两件**结构**检查，不做语义打分：
#   ① 至少 2 个句末标点 —— 一句话写不完「问题→策略→结果」+ 契合点；
#   ② 必须出现方向契合信号 —— 对应 09-04 明确保留的「价值结论」那一句。
# 注意：这里不是用关键词判断文章好坏，而是检查「结论句写了没有」，属结构检查。
WWR_MIN_SENTENCES = 2
WWR_WARN_CHARS = 120
WWR_FIT_SIGNALS = (
    "鼻-脑", "鼻脑", "经鼻", "鼻腔", "鼻", "cns", "中枢", "脑",
    "血脑屏障", "bbb", "肺部", "吸入", "雾化", "干粉", "递送",
    "团队", "迁移", "可迁移", "借鉴", "契合", "参考", "启示", "启发", "方向",
)

# ---- 本期排除项可见性（2026-09-08 用户裁定）----
# 不可见的剔除等于没做。2026-09-08 v7 轮队列 16 篇、报告只出 3 篇，其中 5 篇是
# 复核环节以「已推送」为由排除、1 篇因摘要缺失跳过——报告里一句都没提，用户只能
# 看到「鼻-脑文章不见了」，无法判断是检索漏了还是被有意排除。此后队列里任何未
# 进入报告的候选，都必须在报告头部交代去向与篇名。
EXCLUDED_REASON_LABELS = {
    "already_pushed": "已推送",
    "below_min_score": "未达推荐线",
    "non_delivery": "非递送研究",
    "out_of_scope": "主题外",
    "missing_abstract": "摘要缺失",
    "unreviewed": "未获复核结论",
    "other": "其他",
}
EXCLUDED_REASON_ORDER = (
    "already_pushed",
    "non_delivery",
    "below_min_score",
    "out_of_scope",
    "missing_abstract",
    "unreviewed",
    "other",
)


def _list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [clean_text(item) for item in value if clean_text(item)]
    if clean_text(value):
        return [clean_text(value)]
    return []


def _term_explanations(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


_SENTENCE_END = re.compile(r"[。！？；!?;]")


def why_worth_reading_errors(why: str, prefix: str) -> list[str]:
    """检查「为什么值得看」是否守住 09-04 裁定的撰写契约（W1）。

    只查结构，不查语义：一句话写不完「问题 → 策略 → 结果 + 契合点」，
    所以句数是可机械判定的下限；契合点同理，检查的是「结论句写了没有」。
    长度只给 WARN——09-04 明确反对凑字数，故不设硬下限。
    """
    errors: list[str] = []
    sentences = len(_SENTENCE_END.findall(why))
    if sentences < WWR_MIN_SENTENCES:
        message = (
            f"{prefix}.why_worth_reading 必须写成「问题 → 策略 → 结果」的完整论述，"
            f"至少 {WWR_MIN_SENTENCES} 句；当前 {sentences} 句、{len(why)} 字，"
            f"疑似退化为一句话概览（契约见 CLOUD_RUN.md 的正面范例）"
        )
        errors.append(message)
    lowered = why.casefold()
    if not any(signal in lowered for signal in WWR_FIT_SIGNALS):
        errors.append(
            f"{prefix}.why_worth_reading 结尾缺少方向契合点：须点明与鼻-脑/CNS/肺部递送"
            f"或团队方向的关系（迁移、借鉴、契合、参考、启示等表述均可）"
        )
    return errors


def validate_article(
    article: dict[str, Any],
    index: int,
    strict: bool,
    require_term_explanations: bool,
    rating_dims: list[str] | None = None,
    bonus_dims: dict[str, int] | None = None,
    axis_values: tuple | None = None,
) -> list[str]:
    errors: list[str] = []
    if rating_dims is None:
        rating_dims = list(CONTENT_SCORE_FIELDS)
    if bonus_dims is None:
        bonus_dims = dict(CONTENT_BONUS)
    if axis_values is None:
        axis_values = (R_VALUES, F_VALUES, D_VALUES)
    prefix = f"article[{index}]"
    for field in ("title", "chinese_title", "journal", "publication_date", "url", "article_type"):
        if not clean_text(article.get(field)):
            errors.append(f"{prefix}.{field} 为必填字段")
    score = article.get("recommendation_score")
    if not isinstance(score, int) or not 0 <= score <= 100:
        errors.append(f"{prefix}.recommendation_score 必须是0到100之间的整数")
    component_scores = article.get("component_scores") or {}
    # v13：三轴 R/F/D 取值范围（AI 读摘要判定，rel = 100×R×(0.65+0.35D)×(0.80+0.20F)）
    for axis, values in (("R", axis_values[0]), ("F", axis_values[1]), ("D", axis_values[2])):
        raw = article.get(axis)
        if raw is None:
            errors.append(f"{prefix}.{axis} 为必填字段（三轴契合度：R 给药途径 / F 制剂形式 / D 疾病）")
        elif not isinstance(raw, (int, float)) or raw not in values:
            errors.append(f"{prefix}.{axis} 只能是 {'/'.join(str(v) for v in values)} 之一")
    # v13：内容评分维度（0-100 整数；综述内容层降级，可缺省）
    for field in rating_dims:
        value = article.get(field)
        if value is not None and (not isinstance(value, int) or not 0 <= value <= 100):
            errors.append(f"{prefix}.{field} 必须是0到100之间的整数（内容评价维度）")
    # content_rationale：分数可解释性（2026-09-16 用户裁定）
    # 研究论文必须给每个内容维度写一句"为什么这个分"——分数没有依据就是拍脑袋，
    # 学生也无法从"95 分"里学到任何东西。综述内容层降级、不评内容分，故不要求。
    article_type = clean_text(article.get("article_type")).casefold()
    if "综述" not in article_type and "review" not in article_type:
        rationale = article.get("content_rationale")
        if not isinstance(rationale, dict):
            errors.append(
                f"{prefix}.content_rationale 为必填字段（研究论文须逐维度解释内容分打分依据）"
            )
        else:
            seen_rationale: set[str] = set()
            for field in rating_dims:
                text = clean_text(rationale.get(field))
                if not text:
                    errors.append(
                        f"{prefix}.content_rationale.{field} 为必填字段（该维度的打分依据）"
                    )
                    continue
                if len(text) < RATIONALE_MIN_CHARS:
                    errors.append(
                        f"{prefix}.content_rationale.{field} 只有 {len(text)} 字，"
                        f"须用自然流畅的句子落到本篇的具体瓶颈/证据/机制，"
                        f"禁止「针对明确的递送瓶颈」这类万能短语"
                    )
                if text in seen_rationale:
                    errors.append(
                        f"{prefix}.content_rationale.{field} 与其他维度文字雷同，须各自独立展开"
                    )
                seen_rationale.add(text)
    # v13：加分项（0/1，缺省=不加）
    for field in bonus_dims:
        value = article.get(field)
        if value is not None and value not in (0, 1, True, False):
            errors.append(f"{prefix}.{field} 只能是 0/1（加分项：有则加、无则不加）")
    why = clean_text(article.get("why_worth_reading"))
    if not why:
        errors.append(f"{prefix}.why_worth_reading 为必填字段")
    else:
        errors.extend(why_worth_reading_errors(why, prefix))
    route = clean_text(article.get("route_class")).casefold()
    if route and route not in ROUTE_CLASS_VALUES:
        errors.append(
            f"{prefix}.route_class 只能是 {'/'.join(ROUTE_CLASS_VALUES)} 之一"
            f"（按给药途径的定性判定，先选后排）"
        )
    elif strict and not route:
        errors.append(f"{prefix}.route_class 为必填字段（给药途径定性判定）")
    if route in ROUTE_EXCLUDED:
        errors.append(
            f"{prefix}.route_class={route} 属定性排除，不应出现在 articles 里；"
            f"请移入 metadata.excluded（先按主题选，再对入选者评分）"
        )
    findings = _list(article.get("core_findings"))
    if len(findings) < 1:
        errors.append(f"{prefix}.core_findings 必须至少包含1条受证据约束的要点")
    terms = _term_explanations(article.get("term_explanations"))
    if require_term_explanations and not terms:
        errors.append(f"{prefix}.term_explanations 必须覆盖本篇论文中使用的专业术语")
    seen_terms: set[str] = set()
    for term_index, item in enumerate(terms):
        term_prefix = f"{prefix}.term_explanations[{term_index}]"
        term = clean_text(item.get("term"))
        term_en = clean_text(item.get("term_en"))
        academic = clean_text(item.get("academic_explanation"))
        plain = clean_text(item.get("plain_explanation"))
        if not term:
            errors.append(f"{term_prefix}.term 为必填字段")
        else:
            key = term.casefold()
            if key in seen_terms:
                errors.append(f"{term_prefix}.term 与本篇论文中的其他术语重复")
            seen_terms.add(key)
        if not term_en:
            errors.append(f"{term_prefix}.term_en 为必填字段（英文原词）")
        if not academic:
            errors.append(f"{term_prefix}.academic_explanation 为必填字段")
        if not plain:
            errors.append(f"{term_prefix}.plain_explanation 为必填字段")
        if academic and plain and academic == plain:
            errors.append(f"{term_prefix} 的学术解释和大白话解释不能完全相同")
    inspiration = article.get("research_inspiration") or {}
    if not isinstance(inspiration, dict):
        errors.append(f"{prefix}.research_inspiration 必须是对象")
    else:
        for field in CORE_INSPIRATION:
            if not _list(inspiration.get(field)):
                errors.append(f"{prefix}.research_inspiration.{field} 为必填字段")
    if not 1 <= len(_list(article.get("tags"))) <= 8:
        errors.append(f"{prefix}.tags 必须包含1–8个聚焦标签")
    centrality = clean_text(article.get("delivery_centrality")).casefold()
    if centrality and centrality not in DELIVERY_CENTRALITY_VALUES:
        errors.append(
            f"{prefix}.delivery_centrality 只能是 {'/'.join(DELIVERY_CENTRALITY_VALUES)} "
            f"之一（递送系统在本研究中的地位）"
        )
    elif strict and not centrality:
        errors.append(f"{prefix}.delivery_centrality 为必填字段（core/tool/non_delivery）")
    if strict and article.get("score_status") != "evidence_reviewed":
        errors.append(f"Codex 核对摘要或全文后，{prefix}.score_status 必须设为 evidence_reviewed")
    if article.get("strong_recommendation") and len(_list(article.get("strong_recommendation_reasons"))) < 1:
        errors.append(f"强烈推荐时必须填写 {prefix}.strong_recommendation_reasons")
    return errors


def stars(score: int) -> str:
    """把 0-100 的**推荐总分**折算为 1-5 星。

    2026-09-08：原本这里传的是 relevance。但 relevance 已于同日改为准入条件
    （只回答「是否命中关注方向」），值不再表达相关性高低——实测 16 篇全部落在
    36-46，导致每篇都显示 ★★☆☆☆，与同一行的「推荐指数 96/100」自相矛盾。
    改用推荐总分，星级才与旁边的数字同源、可比。
    """
    filled = max(1, min(5, round(score / 20)))
    return "★" * filled + "☆" * (5 - filled)


def content_score(
    article: dict[str, Any],
    rating_dims: list[str] | None = None,
    bonus_dims: dict[str, int] | None = None,
) -> int:
    """内容分 = 评分维度简单平均 + 加分项。

    2026-09-16 起它是「本期最值得阅读」的排序依据：最终分里期刊占 0.70，
    内容从及格做到满分只值 8 分，还不如期刊跳两档（7 分）——最终分高只说明
    「发得好」，不说明「做得好」。按内容分另排一次，才能把做得扎实但期刊档位
    一般的论文挑出来。
    """
    if rating_dims is None:
        rating_dims = list(CONTENT_SCORE_FIELDS)
    if bonus_dims is None:
        bonus_dims = dict(CONTENT_BONUS)
    average = round(sum(int(article.get(field) or 0) for field in rating_dims) / len(rating_dims))
    bonus = sum(value for field, value in bonus_dims.items() if article.get(field) in (1, True))
    return average + bonus


def is_review_article(article: dict[str, Any]) -> bool:
    text = clean_text(article.get("article_type")).casefold()
    return "综述" in text or "review" in text


def route_label(article: dict[str, Any]) -> str:
    """把给药途径与递送主体性的定性判定渲染成人话。

    2026-09-08：分项里的「相关性 {relevance}」已从展示中移除——relevance 于同日改为
    准入条件（只回答「是否命中关注方向」），实测 16 篇全部落在 36-46，于是出现
    「推荐指数 96/100」旁边挂着「相关性 36」的自相矛盾展示。改用定性标签，
    数字只保留真正参与加权的四个维度，语义不掺水。
    """
    route = clean_text(article.get("route_class")).casefold()
    centrality = clean_text(article.get("delivery_centrality")).casefold()
    parts: list[str] = []
    if route in ROUTE_CLASS_LABELS:
        parts.append(ROUTE_CLASS_LABELS[route])
    if centrality in CENTRALITY_LABELS and centrality != "non_delivery":
        parts.append(CENTRALITY_LABELS[centrality])
    return " · ".join(parts) if parts else "未判定"


def render_team_line(team: Any) -> str:
    """把 enrich_team.py 补出的研究团队渲染成元数据块里的一行。

    措辞必须与「是不是事实」严格对应，不能三级都长得一样：
      - openalex_corresponding / high      直接给姓名+机构+国别，不加限定词
      - inferred_last_author   / low       说明未标记谁牵头，是取末位作者推断
      - fallback_tail_authors  / unverified  说明没有机构信息、待核实

    标题恒为「研究团队」，不写「通讯作者」——推断级和保底级往往并不真是通讯作者，
    写成通讯作者等于把猜测包装成事实。
    """
    if not isinstance(team, dict):
        return ""
    members = [
        item for item in (team.get("members") or [])
        if isinstance(item, dict) and clean_text(item.get("name"))
    ]
    source = clean_text(team.get("source"))
    if not members:
        return "- 研究团队：未获取到（各数据源均无可用作者记录）"
    # 通讯作者一律全列：多位通讯本身就是信息（跨机构合作、双负责人），
    # 截断成"前两位 + 等 N 位"会把这些丢掉。上限只用于防御异常脏数据。
    max_listed = 8
    parts: list[str] = []
    for member in members[:max_listed]:
        name = clean_text(member.get("name"))
        if member.get("institution_suspect"):
            # 数据源把单位识别成政府部门（如「Ministry of Education」）→ 机构与国家都不可信，
            # 只留姓名。宁可少给信息，也不能把错误归属当事实呈现。
            parts.append(f"{name}（机构待核实）")
            continue
        detail = "，".join(
            value for value in (
                clean_text(member.get("institution")),
                clean_text(member.get("country")),
            ) if value
        )
        parts.append(f"{name}（{detail}）" if detail else name)
    text = "、".join(parts)
    if len(members) > max_listed:
        text += f" 等 {len(members)} 位"
    notes: list[str] = []
    if any(item.get("institution_suspect") for item in members):
        notes.append("机构归属疑似有误（数据源识别为政府部门），机构与国家不予显示")
    if source == "inferred_last_author":
        notes.append("低置信度：未标记通讯作者，取末三位作者")
    elif source == "fallback_tail_authors":
        notes.append("待核实：无机构信息，仅作者名单末三位")
    if notes:
        text += "　⚠ " + "；".join(notes)
    return f"- 研究团队：{text}"


def line_items(values: Any, prefix: str = "- ") -> list[str]:
    return [f"{prefix}{item}" for item in _list(values)]


def render_article(
    article: dict[str, Any],
    rank: int,
    rating_dims: list[str] | None = None,
    bonus_dims: dict[str, int] | None = None,
) -> str:
    if rating_dims is None:
        rating_dims = list(CONTENT_SCORE_FIELDS)
    if bonus_dims is None:
        bonus_dims = dict(CONTENT_BONUS)
    strong = bool(article.get("strong_recommendation"))
    heading = f"### {rank}. {clean_text(article['chinese_title'])}"
    if strong:
        heading += "　🔥 **强烈推荐**"
    doi = normalize_doi(article.get("doi")) or "暂无/需核实"
    components = article.get("component_scores") or {}
    rel = f_rel(article.get("R", 0.05), [article.get("D", 0.0), article.get("F", 0.0)])
    content_avg = round(sum(int(article.get(f) or 0) for f in rating_dims) / len(rating_dims))
    content_bonus = sum(bonus_dims[f] for f in bonus_dims if article.get(f) in (1, True))
    content = content_avg + content_bonus
    qual = int(components.get("quality") or 0)
    is_review_display = "综述" in clean_text(article.get("article_type")).casefold() or "review" in clean_text(article.get("article_type")).casefold()
    tags = " ".join(
        tag if str(tag).startswith("#") else f"#{clean_text(tag).replace(' ', '')}"
        for tag in _list(article.get("tags"))
    )
    team_line = render_team_line(article.get("research_team"))
    sections = [
        heading,
        "",
        f"**英文原题：** {clean_text(article['title'])}",
        "",
        f"- 期刊：{clean_text(article['journal'])}",
        f"- 发表日期：{clean_text(article['publication_date'])}",
        f"- DOI：{doi}",
        f"- 论文链接：{clean_text(article['url'])}",
        f"- 论文类型：{clean_text(article['article_type'])}",
        *([team_line] if team_line else []),
        "",
        f"**推荐指数：{article['recommendation_score']}/100**",
        f"**推荐星级：{stars(int(article.get('recommendation_score') or 0))}**",
        (
            f"三轴契合 {axis_text(article)}（rel={rel}）｜"
            f"{'内容层降级（综述）' if is_review_display else f'内容 {content}（平均{content_avg}+加分{content_bonus}）'}"
            f"｜期刊 {qual}" + (f"（{journal_tier_label(qual)}）" if journal_tier_label(qual) else "")
        ),
        f"**方向：** {route_label(article)}",
        "",
        f"**为什么值得看：** {clean_text(article['why_worth_reading'])}",
        "",
        "**核心发现**",
        "",
    ]
    sections.extend(f"{number}. {finding}" for number, finding in enumerate(_list(article["core_findings"]), 1))
    sections.extend(["", "**对我的研究有什么启发**", ""])
    labels = {
        "experimental_design": "可借鉴的实验设计",
        "methods": "值得采用的技术",
        "key_entities_mechanisms": "值得关注的对象/机制",
        "target_system": "向目标研究体系延伸",
        "future_direction": "潜在研究或基金方向",
        "paper_potential": "高水平论文潜力",
        "limitations_validation": "局限与验证需求",
    }
    inspiration = article["research_inspiration"]
    # 必填三项在前，可选项有内容才出现（没有就整行不显示，不留空壳）
    for field in list(CORE_INSPIRATION) + list(OPTIONAL_INSPIRATION):
        value = "；".join(_list(inspiration.get(field)))
        if not value:
            continue
        sections.append(f"- **{labels[field]}：** {value}")
    # ---- 术语后移（2026-09-16 用户裁定）----
    # 原来夹在「核心发现」与「研究启发」之间，把「讲了什么 → 对我有什么用」的
    # 阅读链打断。移到启发之后当附录：想查再查，不打断主线。
    terms = _term_explanations(article.get("term_explanations"))
    if terms:
        sections.extend(["", "**学术名词双重解释**", ""])
        for number, item in enumerate(terms, 1):
            term = clean_text(item.get("term"))
            term_en = clean_text(item.get("term_en"))
            heading = f"{number}. **{term_en}（{term}）**" if term_en else f"{number}. **{term}**"
            sections.extend([
                heading,
                f"   - 学术解释：{clean_text(item.get('academic_explanation'))}",
                f"   - 大白话：{clean_text(item.get('plain_explanation'))}",
            ])
    if strong:
        sections.extend(["", "**🔥 强烈推荐理由**", ""])
        sections.extend(line_items(article.get("strong_recommendation_reasons")))
    verification = _list(article.get("needs_verification"))
    if verification:
        sections.extend(["", "**需核实：** " + "；".join(verification)])
    sections.extend(["", f"**重点标记：** {tags}"])
    return "\n".join(sections)


def build_excluded_note(
    metadata: dict[str, Any],
    all_articles: list[dict[str, Any]],
    queue_path: str | None = None,
) -> str:
    """生成报告头部的「本期排除」提示。

    excluded 由复核环节写入 payload["metadata"]["excluded"]，每项含
    doi / title / queue_score / reason。reason 取值见 EXCLUDED_REASON_LABELS。
    """
    # 已写入复核结果的条目（含 non_delivery）由 centrality_note 负责展示，
    # 这里必须剔除——否则 agent 把 non_delivery 同时写进 metadata.excluded 时
    # 同一篇会在报告头部出现两次（2026-09-08 发现的防呆缺口）。
    reviewed_dois: set[str] = set()
    for article in all_articles:
        key = normalize_doi(article.get("doi"))
        if key:
            reviewed_dois.add(key)

    excluded: list[dict[str, Any]] = []
    accounted: set[str] = set(reviewed_dois)
    for item in metadata.get("excluded") or []:
        if not isinstance(item, dict):
            continue
        key = normalize_doi(item.get("doi"))
        if key and key in reviewed_dois:
            continue
        if key:
            accounted.add(key)
        excluded.append(item)

    # 兜底对账：即使 agent 没填 metadata.excluded，队列里没出现在复核结果中的
    # 候选也必须被点名，否则静默丢失无从发现（2026-09-08 v7 轮的教训）。
    if queue_path and Path(queue_path).exists():
        queue_payload = load_json(queue_path, {})
        for candidate in queue_payload.get("candidates") or []:
            key = normalize_doi(candidate.get("doi"))
            if key and key in accounted:
                continue
            excluded.append(
                {
                    "doi": candidate.get("doi"),
                    "title": candidate.get("title"),
                    "queue_score": candidate.get("recommendation_score"),
                    "reason": "unreviewed",
                }
            )
            if key:
                accounted.add(key)

    if not excluded:
        return ""

    buckets: dict[str, list[str]] = {}
    for item in excluded:
        reason = clean_text(item.get("reason")).casefold() or "other"
        title = clean_text(item.get("chinese_title")) or clean_text(item.get("title")) or "（无标题）"
        buckets.setdefault(reason, []).append(title)

    parts: list[str] = []
    reasons = list(EXCLUDED_REASON_ORDER) + sorted(set(buckets) - set(EXCLUDED_REASON_ORDER))
    for reason in reasons:
        titles = buckets.get(reason) or []
        if not titles:
            continue
        label = EXCLUDED_REASON_LABELS.get(reason, reason)
        shown = "、".join(title[:40] for title in titles[:3])
        more = "等" if len(titles) > 3 else ""
        parts.append(f"{label} {len(titles)} 篇（{shown}{more}）")
    return f"本期排除 {len(excluded)} 篇：" + "；".join(parts)


def render_report(
    payload: dict[str, Any],
    strict: bool = True,
    min_score: int = 70,
    queue_path: str | None = None,
    rating_dims: list[str] | None = None,
    bonus_dims: dict[str, int] | None = None,
    axis_values: tuple | None = None,
) -> str:
    """渲染报告。min_score 为推荐分下限（代码层强制 70 分线，2026-09-04 用户裁定）：

    字段校验先行（agent 交付的每篇都全量把关），再过滤低于 min_score 的论文——
    低分论文即使被复核写入 reviewed_articles 也不再进入报告，宁缺毋滥，
    保证「云端/本地/任何执行者」跑出来的报告口径一致。

    queue_path 指向复核队列 review_queue.json 时，脚本会自动做一次对账：
    队列里有、复核结果里没有的候选会被补进「本期排除」提示（2026-09-08 用户裁定）。
    """
    articles = payload.get("articles") or []
    if not isinstance(articles, list):
        raise TypeError("articles 必须是数组")
    all_articles = [item for item in articles if isinstance(item, dict)]
    if rating_dims is None:
        rating_dims = list(CONTENT_SCORE_FIELDS)
    if bonus_dims is None:
        bonus_dims = dict(CONTENT_BONUS)
    if axis_values is None:
        axis_values = (R_VALUES, F_VALUES, D_VALUES)
    errors: list[str] = []
    require_term_explanations = clean_text(payload.get("term_explanation_mode")).casefold() == "dual"
    for index, article in enumerate(articles):
        if not isinstance(article, dict):
            errors.append(f"article[{index}] 必须是对象")
        else:
            errors.extend(validate_article(article, index, strict, require_term_explanations, rating_dims, bonus_dims, axis_values))
    ideas = _list(payload.get("research_ideas"))
    if articles and not 1 <= len(ideas) <= 3:
        errors.append("research_ideas 必须包含1–3个以证据为基础的研究思路")
    if strict and not 0 <= len(articles) <= 10:
        errors.append("articles 最多只能包含10篇论文")
    if errors:
        raise ValueError("已复核数据验证失败：\n- " + "\n- ".join(errors))

    # ---- 递送主体性处理（2026-09-07 用户裁定）----
    # 先排除 non_delivery（材料本身即效应器，不属于递送研究），再给 core 加分。
    # 顺序不能颠倒：core 的加分可能让边缘论文越过下方 70 分线，而 non_delivery
    # 无论多少分都不该进报告。
    centrality_note = ""
    # 先收集被判 non_delivery 的标题再过滤——标题要写进报告。
    # 理由：误判不可见就无法纠正。09-07 曾把「普鲁士蓝纳米酶微针」（有剂型、
    # 属 tool）误判为 non_delivery，若报告只报篇数不报篇名，用户只能看到
    # 「少了 1 篇」却不知道少了哪篇，误伤会长期潜伏。
    non_delivery_titles = [
        clean_text(a.get("chinese_title")) or clean_text(a.get("title")) or "（无标题）"
        for a in articles
        if clean_text(a.get("delivery_centrality")).casefold() == "non_delivery"
    ]
    non_delivery_count = len(non_delivery_titles)
    if non_delivery_count:
        articles = [
            a for a in articles
            if clean_text(a.get("delivery_centrality")).casefold() != "non_delivery"
        ]
        listed = "；".join(item[:40] for item in non_delivery_titles[:5])
        more = "等" if non_delivery_count > 5 else ""
        centrality_note = (
            f"有 {non_delivery_count} 篇判定为「非递送研究」"
            f"（研究中不含制剂/递送系统这一层），未收录：{listed}{more}"
        )
    for article in articles:
        # ---- v13 最终分：0.10·rel + 0.20·content + 0.70·qual ----
        # rel = AI 判三轴；content = 4 项平均 + 3 加分；qual = 期刊档位（元数据）。
        # 综述内容层降级：只 rel + qual（归一化到 0-100）。
        article_type = clean_text(article.get("article_type")).casefold()
        is_review = "综述" in article_type or "review" in article_type
        rel = f_rel(article.get("R", 0.05), [article.get("D", 0.0), article.get("F", 0.0)])
        comp = article.get("component_scores") or {}
        qual = int(comp.get("quality") or 0)
        score_evidence = article.setdefault("score_evidence", {})
        if isinstance(score_evidence, dict):
            score_evidence.setdefault("final_score", []).append(f"rel = {rel}")
        if is_review:
            final = round((W_REL * rel + W_QUAL * qual) / (W_REL + W_QUAL))
            article["recommendation_score"] = max(0, min(100, final))
            if isinstance(score_evidence, dict):
                score_evidence["final_score"].append(
                    f"综述内容层降级：最终分 = (0.10·{rel} + 0.70·{qual})/0.80 = {final}"
                )
        else:
            content_avg = round(sum(int(article.get(f) or 0) for f in rating_dims) / len(rating_dims))
            bonus = sum(bonus_dims[f] for f in bonus_dims if article.get(f) in (1, True))
            content = content_avg + bonus
            final = round(W_REL * rel + W_CONTENT * content + W_QUAL * qual)
            article["recommendation_score"] = max(0, min(100, final))
            if isinstance(score_evidence, dict):
                score_evidence["final_score"].append(
                    f"最终分 = 0.10·{rel} + 0.20·{content}（平均{content_avg}+加分{bonus}） + 0.70·{qual} = {final}"
                )
    payload["articles"] = articles

    # ---- 代码层强制推荐分下限（70 分线）----
    # 校验之后才过滤：<min_score 的论文不进入报告。全部被滤时走下方零推荐分支。
    min_score_note = ""
    if min_score is not None:
        below = [a for a in articles if int(a.get("recommendation_score") or 0) < min_score]
        if below:
            articles = [a for a in articles if int(a.get("recommendation_score") or 0) >= min_score]
            min_score_note = f"有 {len(below)} 篇低于 {min_score} 分推荐线，未收录（宁缺毋滥）"
        payload["articles"] = articles  # 让调用方（main 的打印）看到过滤后的篇数

    # ---- 研究灵感锚定校验（2026-09-07 用户裁定）----
    # 灵感只能锚定"本期被推荐的条目"。凡引用本期不存在的论文（典型来源：上一批残留、
    # 会话上下文、模型记忆）的灵感条目一律删除，并在报告里注明删除条数——宁可少一条，
    # 不能出现"本期"标签下挂着本期找不到的文献。
    idea_note = ""
    ideas, dropped_ideas = anchor_ideas(_list(payload.get("research_ideas")), articles)
    if dropped_ideas:
        payload["research_ideas"] = ideas
        idea_note = f"有 {dropped_ideas} 条研究灵感因未锚定本期推荐条目已移除"

    report_date = clean_text(payload.get("date")) or datetime.now().astimezone().date().isoformat()
    metadata = payload.get("metadata") or {}
    retrieved = int(metadata.get("retrieved_count") or 0)
    screened = int(metadata.get("screened_count") or 0)
    articles = sorted(articles, key=lambda item: int(item.get("recommendation_score") or 0), reverse=True)
    # 内容分前三：只看内容分，综述排除（综述内容层降级，本就没有内容分）
    by_content = sorted(
        (item for item in articles if not is_review_article(item)),
        key=lambda item: content_score(item, rating_dims, bonus_dims),
        reverse=True,
    )
    for offset, article in enumerate(by_content[:3]):
        article["content_rank"] = offset + 1
    parts = [
        "# 【今日科研文献雷达】",
        "",
        f"日期：{report_date}  ",
        f"检索论文：{retrieved}篇  ",
        f"筛选论文：{screened}篇  ",
        f"最终推荐：{len(articles)}篇",
        "",
    ]
    notes = []
    if idea_note:
        notes.append(idea_note)
    if centrality_note:
        notes.append(centrality_note)
    if min_score_note:
        notes.append(min_score_note)
    excluded_note = build_excluded_note(metadata, all_articles, queue_path)
    if excluded_note:
        notes.append(excluded_note)
    warnings = _list(metadata.get("warnings"))
    if warnings:
        notes.insert(0, "检索提示：" + "；".join(warnings))
    if notes:
        parts.extend(["> " + "；".join(notes), ""])
    if not articles:
        parts.extend([
            "今天没有达到推荐阈值且证据充分的论文。宁缺毋滥，不用低相关性论文填充名额。",
            "",
            "## 今日研究灵感",
            "",
            "今日暂无足够文献证据形成可靠研究灵感。",
        ])
        return "\n".join(parts).rstrip() + "\n"

    parts.append("\n\n---\n\n".join(render_article(article, rank, rating_dims, bonus_dims) for rank, article in enumerate(articles, 1)))
    # ---- 本期最值得阅读前三名（2026-09-16 改版）----
    # 以前按最终分选，而正文就是按最终分排序的，所以板块必然等于正文前三篇、
    # 内容重复。现在改为**按内容分**选，与正文排序脱钩：它挑的是「做得好」的，
    # 正文排的是「综合分高」的，两者不一致时恰恰最有用（做得扎实但期刊档位一般
    # 的论文会被这个板块捞出来）。
    # 不回抄正文：这里不给「问题→策略→结果」，只给内容分的四个客观维度
    # 与「值得学习的一点」，避免与正文的推荐理由重复（2026-09-08 的老问题）。
    if by_content:
        parts.extend(["", "## 本期最值得阅读前三名", ""])
        medals = ("🥇", "🥈", "🥉")
        for index, article in enumerate(by_content[:3]):
            score = content_score(article, rating_dims, bonus_dims)
            final_score = int(article.get("recommendation_score") or 0)
            parts.append(
                f"{medals[index]} **{clean_text(article['chinese_title'])}**"
                f"（内容分 {score}｜综合分 {final_score}）"
            )
            parts.append("")
            # 按「真实瓶颈 → 证据链 → 机制新颖 → 构效可迁移」展开，每维一句打分依据
            ordered = [field for field in CONTENT_DIM_ORDER if field in rating_dims]
            ordered += [field for field in rating_dims if field not in CONTENT_DIM_ORDER]
            rationale = article.get("content_rationale") or {}
            for field in ordered:
                label = CONTENT_DIM_LABELS.get(field, field)
                score = int(article.get(field) or 0)
                line = f"   · {label} {score}"
                why = clean_text(rationale.get(field))
                if why:
                    line += f"　{why}"
                parts.append(line)
            bonuses = [
                f"{BONUS_LABELS.get(field, field)} +{value}"
                for field, value in bonus_dims.items()
                if article.get(field) in (1, True)
            ]
            if bonuses:
                parts.append(f"   加分：{'、'.join(bonuses)}")
            reason = clean_text(article.get("top3_reason"))
            if reason:
                parts.append(f"   值得学习的一点：{reason}")
            parts.append("")
    parts.extend(["## 今日研究灵感", ""])
    if ideas:
        parts.extend(f"{index}. {idea}" for index, idea in enumerate(ideas, 1))
    else:
        parts.append("本期没有可锚定到推荐条目的研究灵感（已移除未锚定条目）。")
    return "\n".join(parts).rstrip() + "\n"


def anchor_ideas(ideas: list[str], articles: list[dict]) -> tuple[list[str], int]:
    """只保留能锚定到本期推荐条目的研究灵感，返回 (保留条目, 被移除条数)。

    锚点取本期每篇论文的序号（第N篇）、中文标题、英文标题、DOI、链接与重点标记标签；
    命中任一即视为已锚定。空灵感列表直接原样返回（不视为需要移除）。
    """
    if not ideas or not articles:
        return list(ideas), 0
    anchors: list[str] = []
    for index, article in enumerate(articles, 1):
        anchors.append(f"第{index}篇")
        for key in ("chinese_title", "title", "doi", "url"):
            value = clean_text(article.get(key)).casefold()
            if value:
                anchors.append(value)
        for tag in _list(article.get("tags")):
            value = clean_text(tag).casefold().lstrip("#")
            if value:
                anchors.append(value)
    kept: list[str] = []
    dropped = 0
    for idea in ideas:
        text = clean_text(idea).casefold()
        if any(anchor and anchor in text for anchor in anchors):
            kept.append(idea)
        else:
            dropped += 1
    return kept, dropped


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = ChineseArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="经过复核的 JSON")
    parser.add_argument("--output", required=True, help="Markdown 报告路径")
    parser.add_argument("--allow-draft", action="store_true", help="仅调试时允许使用初步 score_status")
    parser.add_argument(
        "--min-score",
        type=int,
        default=70,
        help="推荐分下限：低于该分的论文不进入报告（宁缺毋滥），默认 70",
    )
    parser.add_argument(
        "--queue",
        help="复核队列 review_queue.json 路径；提供时自动对账，队列里有而复核结果里没有的候选会写进报告头部的「本期排除」",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    payload = load_json(args.input, {})
    rating_dims, bonus_dims = list(CONTENT_SCORE_FIELDS), dict(CONTENT_BONUS)
    axis_values = (R_VALUES, F_VALUES, D_VALUES)
    try:
        from profile_config import load_profile
        profile = load_profile()
        rating_dims, bonus_dims = load_content_scoring(profile)
        axis_values = load_axis_values(profile)
    except Exception:
        pass
    report = render_report(
        payload, strict=not args.allow_draft, min_score=args.min_score, queue_path=args.queue,
        rating_dims=rating_dims, bonus_dims=bonus_dims, axis_values=axis_values,
    )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(report, encoding="utf-8", newline="\n")
    print(f"已将 {len(payload.get('articles') or [])} 篇论文写入报告：{output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

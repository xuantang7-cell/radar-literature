#!/usr/bin/env python3
"""为「已确定推荐」的论文补查研究团队信息。

设计前提（2026-09-16 用户裁定 + 实测）
--------------------------------------
1. **只对已通过复核的论文查**，不在检索阶段全量拉取。推荐 ≤10 篇，按 DOI 单篇查 OpenAlex，
   单次约 10 credits，相对 10000 的账号额度可忽略。
2. **不做 JATS/PMC 全文，也不解析出版社页面**。实测结论：39 篇鼻-脑样本的交叉表里
   「OpenAlex 缺失而 JATS 可得」= 0%——有 PMCID 的几乎全是 OA，而 OA 论文 OpenAlex 基本
   已覆盖；且 fullTextXML 体量大（实测 IncompleteRead / SSL 超时）、需处理 XML 截断，
   出版社页面则有付费墙与反爬。维护一个收益为零的通道不划算。
3. 三级回退，置信度递减，措辞与「是不是事实」严格对应：

   | 级别 | source | confidence | 缺什么 | 给什么 |
   |---|---|---|---|---|
   | 结构化 | openalex_corresponding | high | 什么都不缺 | 明确标记的通讯作者，是事实 |
   | 推断   | inferred_last_author   | low    | 缺"谁是通讯"的标记 | 作者列表与机构齐全，取末位作者代替，是有依据的猜测 |
   | 保底   | fallback_tail_authors  | unverified | 连 OpenAlex 记录都没有 | 只剩其他源留下的姓名串，通常没有机构 |

   前两级差别不在"准不准"，而在"缺的是标记还是整条记录"——推断仍知道单位，保底通常不知道。

4. 机构只到**一级单位**：OpenAlex 的 `lineage` 给的是祖先链（ID 列表），只有当祖先名是自身名的
   子串时才上卷（"Sun Yat-sen University" ⊂ "…School of Pharmaceutical Sciences"），
   避免把研究所过度上卷到国家体系（实测 Mario Negri → IRCCS）。
"""

from __future__ import annotations

import argparse
import os
import re
import time
import urllib.parse
from typing import Any

from common import ChineseArgumentParser, atomic_write_json, clean_text, json_request, load_dotenv_if_present, load_json, normalize_doi

OPENALEX_WORK_SELECT = "id,doi,authorships,corresponding_author_ids"
OPENALEX_INSTITUTION_SELECT = "id,display_name,type,country_code,display_name_alternatives"

SOURCE_OPENALEX = "openalex_corresponding"
SOURCE_INFERRED = "inferred_last_author"
SOURCE_FALLBACK = "fallback_tail_authors"
SOURCE_UNAVAILABLE = "unavailable"

CONFIDENCE_BY_SOURCE = {
    SOURCE_OPENALEX: "high",
    SOURCE_INFERRED: "low",
    SOURCE_FALLBACK: "unverified",
    SOURCE_UNAVAILABLE: "unverified",
}

# ISO 3166-1 alpha-2 → 中文国名。展示用：二字码对少见国家没有可读性，
# 而 emoji/英文国名同样存在"看不懂"的问题，故统一映射为中文。
# 数据来源仍是结构化字段（country_code），映射只发生在渲染前，可供聚合的类型(feature)不受影响。
COUNTRY_NAMES = {
    "CN": "中国", "US": "美国", "GB": "英国", "JP": "日本", "KR": "韩国", "DE": "德国",
    "FR": "法国", "IT": "意大利", "ES": "西班牙", "CA": "加拿大", "AU": "澳大利亚",
    "NL": "荷兰", "BE": "比利时", "CH": "瑞士", "AT": "奥地利", "SE": "瑞典",
    "NO": "挪威", "DK": "丹麦", "FI": "芬兰", "IE": "爱尔兰", "PT": "葡萄牙",
    "PL": "波兰", "CZ": "捷克", "HU": "匈牙利", "GR": "希腊", "RU": "俄罗斯",
    "IN": "印度", "IR": "伊朗", "IL": "以色列", "TR": "土耳其", "SA": "沙特阿拉伯",
    "AE": "阿联酋", "EG": "埃及", "ZA": "南非", "NG": "尼日利亚", "KE": "肯尼亚",
    "ET": "埃塞俄比亚", "GH": "加纳", "TZ": "坦桑尼亚", "UG": "乌干达", "BI": "布隆迪",
    "BR": "巴西", "MX": "墨西哥", "AR": "阿根廷", "CL": "智利", "CO": "哥伦比亚",
    "PE": "秘鲁", "UY": "乌拉圭", "VE": "委内瑞拉", "CU": "古巴",
    "SG": "新加坡", "MY": "马来西亚", "TH": "泰国", "VN": "越南", "ID": "印度尼西亚",
    "PH": "菲律宾", "PK": "巴基斯坦", "BD": "孟加拉国", "LK": "斯里兰卡", "NP": "尼泊尔",
    "NZ": "新西兰", "TW": "中国台湾", "HK": "中国香港", "MO": "中国澳门",
    "UA": "乌克兰", "RO": "罗马尼亚", "BG": "保加利亚", "RS": "塞尔维亚", "HR": "克罗地亚",
    "SI": "斯洛文尼亚", "SK": "斯洛伐克", "LT": "立陶宛", "LV": "拉脱维亚", "EE": "爱沙尼亚",
    "IS": "冰岛", "LU": "卢森堡", "MT": "马耳他", "CY": "塞浦路斯",
    "QA": "卡塔尔", "KW": "科威特", "JO": "约旦", "LB": "黎巴嫩", "MA": "摩洛哥",
    "TN": "突尼斯", "DZ": "阿尔及利亚", "LY": "利比亚", "SD": "苏丹", "ZM": "赞比亚",
    "ZW": "津巴布韦", "MW": "马拉维", "MZ": "莫桑比克", "AO": "安哥拉", "SN": "塞内加尔",
    "CM": "喀麦隆", "CI": "科特迪瓦", "ML": "马里", "BF": "布基纳法索", "NE": "尼日尔",
    "RW": "卢旺达", "CD": "刚果（金）", "CG": "刚果（布）", "GA": "加蓬",
}


def country_label(code: str) -> str:
    """ISO 二字码 → 中文国名；无映射时原样返回二字码（宁可见码，不guess）。"""
    key = clean_text(code).upper()
    return COUNTRY_NAMES.get(key, key)


def _short_id(value: str) -> str:
    return clean_text(value).rsplit("/", 1)[-1]


def _openalex_params() -> dict[str, str]:
    params: dict[str, str] = {}
    mailto = clean_text(os.environ.get("OPENALEX_MAILTO"))
    api_key = clean_text(os.environ.get("OPENALEX_API_KEY"))
    if mailto:
        params["mailto"] = mailto
    if api_key:
        params["api_key"] = api_key
    return params


class InstitutionResolver:
    """批量解析 lineage ID → 机构元数据。

    lineage 是 ID 列表，不预取的话每解析一个祖先就是一次请求（首版实现踩过这个坑）。
    所以两阶段：先把本期所有 lineage ID 一次性批量取回，再逐篇构建。
    """

    def __init__(self, params: dict[str, str]) -> None:
        self._params = params
        self._cache: dict[str, dict[str, Any]] = {}
        self.requests = 0

    def prefetch(self, keys: list[str]) -> None:
        seen: set[str] = set()
        pending: list[str] = []
        for key in keys:
            short = _short_id(key)
            if short and short not in self._cache and short not in seen:
                seen.add(short)
                pending.append(short)
        for start in range(0, len(pending), 40):
            self._fetch(pending[start:start + 40])

    def get(self, openalex_id: str) -> dict[str, Any]:
        return self._cache.get(_short_id(openalex_id), {})

    def _fetch(self, keys: list[str]) -> None:
        if not keys:
            return
        filter_value = "ids.openalex:" + "|".join(keys)
        url = (
            "https://api.openalex.org/institutions?filter="
            + urllib.parse.quote(filter_value)
            + "&select=" + urllib.parse.quote(OPENALEX_INSTITUTION_SELECT, safe=",")
            + "&per-page=" + str(max(50, len(keys)))
        )
        if self._params:
            url += "&" + urllib.parse.urlencode(self._params)
        self.requests += 1
        try:
            payload = json_request(url, timeout=30, retries=2)
        except Exception:
            # 解析失败不该让整期报告塌掉：退化为"无法确认一级单位"，保畱自身名
            for key in keys:
                self._cache.setdefault(key, {})
            return
        for inst in payload.get("results") or []:
            self._cache[_short_id(inst.get("id"))] = {
                "display_name": clean_text(inst.get("display_name")),
                "type": clean_text(inst.get("type")),
                "country_code": clean_text(inst.get("country_code")),
                "aliases": inst.get("display_name_alternatives") or [],
            }
        for key in keys:
            self._cache.setdefault(key, {})


def _is_cjk(text: str) -> bool:
    """是否为中日韩统一表意文字。带声调的拼音（Huázhōng…）属拉丁扩展，不算汉字。"""
    return any("\u4e00" <= ch <= "\u9fff" for ch in text or "")


# 政府部门实体模式（2026-09-16 新增，防护 OpenAlex 机构误解析）。
# 实测案例：Nature Communications 一篇复旦团队的论文，OpenAlex 把**全部 9 位作者**的单位
# 解析成 `Ministry of Education`（韩国教育部），其顶层是 `Government of the Republic of Korea`。
# 为什么不直接用 `type == "government"` 判定：**中科院、NIH、国家自然科学基金委在 OpenAlex
# 里都是 government**，那条规则会大面积误伤——按名称模式识别「政府部门」精准得多。
GOVERNMENT_BODY_PATTERN = re.compile(
    r"\b(ministry of|government of|minist[eè]re|ministerio|ministero)\b",
    re.IGNORECASE,
)


def looks_like_government_body(name: str) -> bool:
    """机构名是否为「政府部门」实体——它不是论文的研究执行单位，命中即判为误解析。"""
    return bool(GOVERNMENT_BODY_PATTERN.search(clean_text(name)))


def chinese_alias(alternatives: list[str]) -> str:
    """从 OpenAlex 机构别名里取第一个真正含汉字的名字。

    `international.zh` 实测全空（10/10 无值），但 `display_name_alternatives` 里常带
    标准中文名——2026-09-16 实测近期鼻-脑样本的中国机构覆盖率 83%（10/12），
    且拼音别名能被 CJK 判定自动跳过。这是结构化数据，不是 AI 翻译，也不是猜测。
    """
    for alt in alternatives or []:
        if isinstance(alt, str) and _is_cjk(alt):
            return clean_text(alt)
    return ""


def localized_name(english: str, country: str, meta: dict[str, Any]) -> str:
    """中国机构显示中文名，其余保持英文（2026-09-16 用户裁定）。

    拿不到中文别名时老实显示英文——宁可让玩家看英文名，也不要拿拼音或不靠谱的译名充数。
    """
    if clean_text(country).upper() == "CN":
        alias = chinese_alias(meta.get("aliases") or [])
        if alias:
            return alias
    return english


def top_level_institution(inst: dict[str, Any], resolver: InstitutionResolver) -> tuple[str, str]:
    """把脱水 institution 归到一级单位，返回 (机构名, ISO 国家码)。

    规则：默认保持自身；只有当某个祖先的名字是自身名的子串（"大学" ⊂ "大学药学院"）
    时才上卷到最短的那个祖先。这样既满足"不要二级单位"，又不会把独立研究所
    过度上卷到国家体系（实测反例：Mario Negri Institute → IRCCS）。
    """
    own_name = clean_text(inst.get("display_name"))
    country = clean_text(inst.get("country_code"))
    lineage = [_short_id(x) for x in (inst.get("lineage") or [])]
    own_id = _short_id(inst.get("id"))
    own_meta = resolver.get(own_id) or {}
    own_display = localized_name(own_name, country, own_meta)
    ancestors = [key for key in lineage if key and key != own_id]
    if not own_name or not ancestors:
        return own_display, country

    resolved = [resolver.get(key) for key in ancestors]
    candidates = [meta for meta in resolved if meta.get("display_name")]
    contained = [
        meta for meta in candidates
        if meta["display_name"].casefold() in own_name.casefold()
    ]
    if contained:
        # 取最短者：越顶层名字通常越短，且已在自身名内出现
        best = min(contained, key=lambda meta: len(meta["display_name"]))
        code = best.get("country_code") or country
        return localized_name(best["display_name"], code, best), code
    return own_display, country


def _author_name(authorship: dict[str, Any]) -> str:
    author = authorship.get("author") or {}
    name = clean_text(author.get("display_name")) or clean_text(authorship.get("raw_author_name"))
    return name


def _member_from_authorship(authorship: dict[str, Any], resolver: InstitutionResolver) -> dict[str, Any]:
    institutions = authorship.get("institutions") or []
    name = _author_name(authorship)
    if not institutions:
        codes = authorship.get("countries") or []
        return {
            "name": name,
            "institution": "",
            "country": country_label(codes[0]) if codes else "",
            "institution_suspect": False,
        }
    inst = institutions[0]
    institution_name, code = top_level_institution(inst, resolver)
    if looks_like_government_body(institution_name):
        # 机构被解析成政府部门 → 数据源明显出错，机构与国家一并作废、只留姓名，
        # 由渲染层标注「机构待核实」。宁可少给信息，也不能给错信息。
        return {
            "name": name,
            "institution": "",
            "country": "",
            "institution_suspect": True,
        }
    return {
        "name": name,
        "institution": institution_name,
        "country": country_label(code),
        "institution_suspect": False,
    }


def team_from_work(work: dict[str, Any], resolver: InstitutionResolver) -> dict[str, Any]:
    """从一篇 OpenAlex work 推导研究团队；返回带 source/confidence 的对象。"""
    authorships = [a for a in (work.get("authorships") or []) if isinstance(a, dict)]
    corresponding = [a for a in authorships if a.get("is_corresponding")]
    if corresponding:
        members = [_member_from_authorship(a, resolver) for a in corresponding]
        return {
            "members": members,
            "source": SOURCE_OPENALEX,
            "confidence": CONFIDENCE_BY_SOURCE[SOURCE_OPENALEX],
            "note": f"OpenAlex 标记通讯作者 {len(corresponding)} 位",
        }
    if not authorships:
        return {
            "members": [],
            "source": SOURCE_UNAVAILABLE,
            "confidence": CONFIDENCE_BY_SOURCE[SOURCE_UNAVAILABLE],
            "note": "OpenAlex 有该文记录但无作者信息",
        }
    # 取末三位作者（2026-09-16 用户裁定，原为只取末位）：无通讯标记时只给一个人，
    # 等于把一个已知不靠谱的假设（"末位=负责人"，OpenAlex 官方实测该假设近半出错）
    # 当成唯一答案呈现；给末三位并标注低置信度，信息更完整，判断权回到使用者手里。
    tail = authorships[-3:]
    members = [_member_from_authorship(item, resolver) for item in tail]
    return {
        "members": members,
        "source": SOURCE_INFERRED,
        "confidence": CONFIDENCE_BY_SOURCE[SOURCE_INFERRED],
        "note": f"该文未标记通讯作者，取末 {len(members)} 位作者（含各自单位）供参考",
    }


def fallback_team(authors: list[str]) -> dict[str, Any]:
    """保底：OpenAlex 查不到该文，用其他源留下来的作者名单末三位。"""
    names = [clean_text(a) for a in authors if clean_text(a)]
    tail = names[-3:]
    if not tail:
        return {
            "members": [],
            "source": SOURCE_UNAVAILABLE,
            "confidence": CONFIDENCE_BY_SOURCE[SOURCE_UNAVAILABLE],
            "note": "各数据源均未提供作者信息",
        }
    return {
        "members": [{"name": name, "institution": "", "country": ""} for name in tail],
        "source": SOURCE_FALLBACK,
        "confidence": CONFIDENCE_BY_SOURCE[SOURCE_FALLBACK],
        "note": "OpenAlex 无该文记录，取作者名单末三位；机构未获取，待核实",
    }


def fetch_work(doi: str, params: dict[str, str], timeout: int) -> dict[str, Any] | None:
    if not doi:
        return None
    url = (
        "https://api.openalex.org/works/doi:" + urllib.parse.quote(doi, safe="")
        + "?select=" + urllib.parse.quote(OPENALEX_WORK_SELECT, safe=",")
    )
    if params:
        url += "&" + urllib.parse.urlencode(params)
    try:
        return json_request(url, timeout=timeout, retries=2)
    except Exception as exc:
        # 404（无记录）与网络/限流都走 not found，由保底逻辑接住；不阻塞整期
        print(f"    [跳过] OpenAlex 查询失败：{exc}")
        return None


def load_queue_authors(queue_path: str | None) -> dict[str, list[str]]:
    if not queue_path:
        return {}
    payload = load_json(queue_path, {})
    out: dict[str, list[str]] = {}
    for candidate in payload.get("candidates") or []:
        doi = normalize_doi(candidate.get("doi"))
        authors = candidate.get("authors") or []
        if doi and authors:
            out[doi] = [str(a) for a in authors]
    return out


def enrich_articles(articles: list[dict[str, Any]], queue_authors: dict[str, list[str]], timeout: int) -> dict[str, int]:
    params = _openalex_params()
    resolver = InstitutionResolver(params)
    stats = {SOURCE_OPENALEX: 0, SOURCE_INFERRED: 0, SOURCE_FALLBACK: 0, SOURCE_UNAVAILABLE: 0}

    # 阶段一：按 DOI 逐篇查 work（每个 DOI 一次请求）
    fetched: list[tuple[dict[str, Any], dict[str, Any] | None, str]] = []
    for article in articles:
        doi = normalize_doi(article.get("doi"))
        fetched.append((article, fetch_work(doi, params, timeout), doi))
        time.sleep(0.2)  # 礼貌间隔，避免短时间连打

    # 阶段二：把所有 lineage ID 一次性批量解析（通常 1 次请求）
    lineage_keys: list[str] = []
    for _, work, _ in fetched:
        for authorship in (work or {}).get("authorships") or []:
            for inst in authorship.get("institutions") or []:
                lineage_keys.extend(inst.get("lineage") or [])
    resolver.prefetch(lineage_keys)
    print(f"  OpenAlex work 请求 {len(fetched)} 次；一级单位批量解析 {resolver.requests} 次")

    for article, work, doi in fetched:
        if work:
            team = team_from_work(work, resolver)
        elif doi in queue_authors:
            team = fallback_team(queue_authors[doi])
        else:
            team = {
                "members": [],
                "source": SOURCE_UNAVAILABLE,
                "confidence": CONFIDENCE_BY_SOURCE[SOURCE_UNAVAILABLE],
                "note": "OpenAlex 无该 DOI 记录，且队列中无作者名单",
            }
        article["research_team"] = team
        stats[team["source"]] = stats.get(team["source"], 0) + 1
        label = (clean_text(article.get("chinese_title")) or clean_text(article.get("title")))[:28] or "(无标题)"
        shown = "、".join(m["name"] for m in team["members"][:8]) or "—"
        extra = f" 等 {len(team['members'])} 位" if len(team["members"]) > 8 else ""
        unit = team["members"][0].get("institution") if team["members"] else ""
        print(f"  [{team['source']}/{team['confidence']}] {label} → {shown}{extra}"
              + (f"（{unit}）" if unit else ""))
    return stats


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = ChineseArgumentParser(description=__doc__)
    parser.add_argument("--reviewed", required=True, help="已复核的 reviewed_articles.json（原地补写）")
    parser.add_argument("--queue", help="review_queue.json；提供时可用于保底取作者名单")
    parser.add_argument("--dry-run", action="store_true", help="只打印不写回")
    parser.add_argument("--timeout", type=int, default=30, help="单次请求超时秒数")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    loaded = load_dotenv_if_present()
    if loaded:
        print(f"[env] 已从 .env 补载：{', '.join(loaded)}（值不回显）")
    args = parse_args(argv)
    payload = load_json(args.reviewed, {})
    articles = [a for a in (payload.get("articles") or []) if isinstance(a, dict)]
    if not articles:
        print("没有可补查的论文条目。")
        return 0
    queue_authors = load_queue_authors(args.queue)
    print(f"开始为 {len(articles)} 篇已推荐论文补查研究团队…")
    stats = enrich_articles(articles, queue_authors, args.timeout)
    total = sum(stats.values()) or 1
    print(
        "研究团队补全："
        + "；".join(f"{key} {stats[key]} 篇（{stats[key] / total:.0%}）" for key in stats)
    )
    if not args.dry_run:
        payload["articles"] = articles
        atomic_write_json(args.reviewed, payload)
        print(f"已写回：{args.reviewed}")
    else:
        print("dry-run，未写回。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""IF 归一化自动分档（配置向导阶段 3a 的「路 B · 不预设白名单」）。

按 OpenAlex 期刊指标（2yr_mean_citedness，近似影响因子）对**样本期刊集合**做
**领域内分位归一化**，切 5 档（L0–L4），产出可直接写进 `quality_tiers` 的映射。

为什么必须「领域内归一化」：影响因子跨领域不可比——肿瘤/材料刊普遍 5–15，
基础学科顶刊只有 2–3。用绝对值切档会系统性错分；用「本领域样本期刊的分位」
才能衡量「领域内相对质量」。定位是初筛层的粗排依据，不是绝对质量评价。

用法：
    python auto_tier_journals.py --input journals.json --output tiers.json
    python auto_tier_journals.py --input journals.json --output tiers.json --bins 0.95,0.85,0.60,0.30
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.parse
import urllib.request
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ChineseArgumentParser, load_dotenv_if_present, load_json  # noqa: E402
from search_papers import resolve_openalex_mailto  # noqa: E402

OPENALEX_SOURCES = "https://api.openalex.org/sources"
TIER_VALUES = {"L0": 100, "L1": 92, "L2": 80, "L3": 75, "L4": 70}
TIER_LABELS = {"L0": "正刊/顶刊", "L1": "大子刊", "L2": "高影响子刊", "L3": "领域头部", "L4": "领域主流"}
# 分位下界（从高到低）：L0 top5% / L1 5–15% / L2 15–40% / L3 40–70% / L4 后 30%。
# 启发式默认值，可按领域调整（--bins 覆盖）。
DEFAULT_BINS = [0.95, 0.85, 0.60, 0.30]


def fetch_metric(name: str, api_key: str, mailto: str, timeout: int = 12) -> tuple[Any, Any]:
    """按期刊名查 OpenAlex Source，返回 (2yr_mean_citedness, h_index)；失败返回 (None, None)。"""
    params: dict[str, str] = {"search": name, "per-page": "1"}
    if mailto:
        params["mailto"] = mailto
    url = OPENALEX_SOURCES + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url)
    if api_key:
        req.add_header("Authorization", f"Bearer {api_key}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None, None
    results = data.get("results") or []
    if not results:
        return None, None
    stats = results[0].get("summary_stats") or {}
    return stats.get("2yr_mean_citedness"), stats.get("h_index")


def tier_by_metric(metrics: dict[str, float], bins: list[float]) -> dict[str, tuple[str, float]]:
    """按 2yr_mean_citedness 做领域内分位切 5 档，返回 {name: (tier, percentile)}。"""
    if not metrics:
        return {}
    sorted_items = sorted(metrics.items(), key=lambda kv: kv[1])
    n = len(sorted_items)
    percentile = {name: rank / (n - 1) for rank, (name, _) in enumerate(sorted_items)}
    result: dict[str, tuple[str, float]] = {}
    for name, _m in metrics.items():
        p = percentile[name]
        if p >= bins[0]:
            tier = "L0"
        elif p >= bins[1]:
            tier = "L1"
        elif p >= bins[2]:
            tier = "L2"
        elif p >= bins[3]:
            tier = "L3"
        else:
            tier = "L4"
        result[name] = (tier, p)
    return result


def main(argv: list[str] | None = None) -> int:
    ap = ChineseArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True, help="期刊清单 JSON：[{\"name\":\"...\",\"count\":N}] 或 [\"...\"]")
    ap.add_argument("--output", required=True, help="档位映射输出 JSON")
    ap.add_argument("--bins", default=",".join(str(b) for b in DEFAULT_BINS),
                    help="分位阈值（从高到低，对应 L0/L1/L2/L3 下界），逗号分隔")
    ap.add_argument("--min-samples", type=int, default=15,
                    help="解析到的期刊数低于该值则警告分档不可靠")
    args = ap.parse_args(argv)

    load_dotenv_if_present(os.path.dirname(os.path.abspath(__file__)))
    api_key = os.environ.get("OPENALEX_API_KEY", "").strip()
    mailto = resolve_openalex_mailto()
    if not api_key:
        print("[auto_tier] 警告：未配置 OPENALEX_API_KEY，走匿名额度（共享出口 IP 易 429）")

    raw = load_json(args.input, [])
    journals: list[dict[str, Any]] = []
    if isinstance(raw, list):
        for item in raw:
            if isinstance(item, str):
                journals.append({"name": item, "count": 1})
            elif isinstance(item, dict) and item.get("name"):
                journals.append({"name": item["name"], "count": item.get("count", 1)})
    if not journals:
        print("错误：--input 里没有有效期刊名")
        return 2

    bins = [float(x) for x in args.bins.split(",") if x.strip()]
    if len(bins) != 4:
        print("错误：--bins 需要 4 个从高到低的分位阈值")
        return 2

    metrics: dict[str, float] = {}
    h_index: dict[str, Any] = {}
    unresolved: list[str] = []
    for j in journals:
        name = j["name"]
        m2, h = fetch_metric(name, api_key, mailto)
        if m2 is None:
            unresolved.append(name)
        else:
            metrics[name] = m2
            h_index[name] = h
        time.sleep(0.2)  # 轻量节流，避免过快触发限流

    tiers = tier_by_metric(metrics, bins)
    out = {
        "tiers": {},
        "unresolved": unresolved,
        "bins": bins,
        "n_journals": len(journals),
        "n_resolved": len(metrics),
    }
    for name, (tier, p) in tiers.items():
        out["tiers"][name] = {
            "tier": tier,
            "value": TIER_VALUES[tier],
            "label": TIER_LABELS[tier],
            "metric_2yr": metrics[name],
            "h_index": h_index.get(name),
            "percentile": round(p, 3),
        }

    out_path = args.output
    out_dir = os.path.dirname(os.path.abspath(out_path))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with open(out_path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)

    if len(metrics) < args.min_samples:
        print(f"警告：解析到 {len(metrics)} 本期刊 < {args.min_samples}，分档不可靠，建议人工校正")
    print(f"已分档 {len(tiers)} 本期刊 → {out_path}")
    if unresolved:
        print(f"未解析 {len(unresolved)} 本（见 output.unresolved，需人工补档位）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

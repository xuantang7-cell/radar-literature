#!/usr/bin/env python3
"""编排每日科研文献雷达的检索与交付流程。"""

from __future__ import annotations

import argparse
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from common import (
    ChineseArgumentParser,
    atomic_write_json,
    load_dotenv_if_present,
    load_json,
    utc_now_iso,
)
from profile_config import DEFAULT_PROFILE, ProfileError, load_profile
from update_research_memory import build_context, load_memory

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent
DEFAULT_HISTORY = SKILL_DIR / "data" / "pushed_articles.json"
DEFAULT_MEMORY = SKILL_DIR / "data" / "research_memory.json"
DEFAULT_RUNS = SKILL_DIR / "data" / "runs"

# 全源基线：检索默认跑满这三个源。少跑任何一个都必须显式告警，
# 因为源缺失会让召回量腰斩（实测丢掉 openalex 后：7459 → 3296，候选 20 → 11）。
FULL_SOURCE_SET = ("europepmc", "crossref", "openalex")


def run_script(name: str, *arguments: str) -> None:
    command = [sys.executable, str(SCRIPT_DIR / name), *arguments]
    subprocess.run(command, check=True)


def source_warnings(sources: str, source_counts: dict[str, Any]) -> list[str]:
    """生成数据源完整性告警。

    少跑一个源或某源返回 0 条都必须显式告警——实测丢掉 openalex 后检索量
    7459 → 3296（−56%）、候选 20 → 11、鼻-脑论文归零，而报告上完全看不出来。
    这类"静默降级"比报错更危险，因此单独抽成函数以便测试。
    """
    warnings: list[str] = []
    counts = source_counts or {}
    requested = [item.strip().lower() for item in (sources or "").split(",") if item.strip()]
    missing = [name for name in FULL_SOURCE_SET if name not in requested]
    if missing:
        warnings.append(
            f"本次未检索数据源：{'、'.join(missing)}"
            f"（全源基线为 {'、'.join(FULL_SOURCE_SET)}）；召回量可能显著下降"
        )
    empty = [name for name in requested if not int(counts.get(name) or 0)]
    if empty:
        warnings.append(f"数据源返回 0 条：{'、'.join(empty)}（该源可能失败或被限流）")
    return warnings


def collect_stage(args: argparse.Namespace) -> Path:
    today = datetime.now().astimezone().date().isoformat()
    output_dir = Path(args.output_dir) if args.output_dir else DEFAULT_RUNS / today
    output_dir.mkdir(parents=True, exist_ok=True)

    def execute_window(label: str, days: int) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
        raw_path = output_dir / f"search_{label}.json"
        fresh_path = output_dir / f"deduplicated_{label}.json"
        ranked_path = output_dir / f"ranked_{label}.json"
        run_script(
            "search_papers.py",
            "--days", str(days),
            "--mode", args.mode,
            "--profile", str(args.profile),
            "--sources", args.sources,
            "--output", str(raw_path),
        )
        run_script(
            "deduplicate.py",
            "filter",
            "--input", str(raw_path),
            "--output", str(fresh_path),
            "--history", str(args.history),
        )
        run_script(
            "rank_papers.py",
            "--input", str(fresh_path),
            "--output", str(ranked_path),
            "--profile", str(args.profile),
            "--threshold", str(args.threshold),
            "--max-results", str(args.max_results),
            "--fresh-days", str(args.fresh_days),
        )
        return load_json(raw_path, {}), load_json(fresh_path, {}), load_json(ranked_path, {})

    # 学术接口只提供日级出版日期，无法可靠判定"近24小时"，因此固定使用 7 天候选池。
    # 新鲜度不再通过"是否回退扩窗"来表达，而是交给 rank_papers.py 的分层名额：
    # 近 fresh_days 天出版的达标论文优先入队，不会被高分旧论文挤掉。
    raw, fresh, ranked = execute_window("7d", 7)
    used_window = f"最近7天（其中近{args.fresh_days}天出版的达标论文优先入队）"
    candidate_count = len(ranked.get("recommendations") or [])
    if candidate_count < args.min_results:
        warnings = [f"候选仅 {candidate_count} 篇，低于 --min-results {args.min_results}；复核后可能不足最低产出量"]
    else:
        warnings = []

    source_errors = raw.get("errors") or []
    warnings += [f"{item.get('source')}: {item.get('error')}" for item in source_errors]

    # 源完整性告警：不允许"静默降级"。少跑一个源或某源返回 0 条都必须在报告里可见。
    warnings += source_warnings(args.sources, raw.get("source_counts") or {})

    if fresh.get("update_count"):
        warnings.append(f"发现 {fresh['update_count']} 篇已推送论文的出版信息更新；不作为新论文重复推荐")
    queue = {
        "generated_at": utc_now_iso(),
        "date": today,
        "mode": args.mode,
        "profile_name": raw.get("profile_name") or "",
        "metadata": {
            "window": used_window,
            "retrieved_count": int(raw.get("retrieved_count") or 0),
            "unique_relevant_count": int(raw.get("unique_relevant_count") or 0),
            "new_after_history_count": int(fresh.get("new_count") or 0),
            "screened_count": int(ranked.get("screened_count") or 0),
            "passing_count": int(ranked.get("passing_count") or 0),
            "fresh_window_count": int(ranked.get("fresh_window_count") or 0),
            "preliminary_recommended_count": int(ranked.get("recommended_count") or 0),
            "threshold": args.threshold,
            "maximum": args.max_results,
            "fresh_days": args.fresh_days,
            "min_results": args.min_results,
            "below_min_results": candidate_count < args.min_results,
            "selection_note": ranked.get("selection_note") or "",
            "source_counts": raw.get("source_counts") or {},
            "warnings": warnings,
        },
        "review_requirement": (
            "这些是元数据初筛候选，不是最终推送结果。Codex 必须阅读可用摘要，并在重要结论不充分时核对出版商页面/全文；"
            "逐项复核评分，排除证据不足或弱相关论文，再写入 reviewed_articles.json。"
            "复核时必须阅读摘要判定每篇是「综述」还是「研究论文」，并把 article_type 字段改写为判定值（综述/研究论文），"
            "不能照抄检索源的类型标签（Journal Article / journal-article / article 无法区分综述）。"
        ),
        "research_memory_context": build_context(load_memory(args.memory), recent=10),
        "scoring_formula": ranked.get("formula"),
        "candidates": ranked.get("recommendations") or [],
        "updates_not_for_new_push": fresh.get("updates") or [],
    }
    queue_path = output_dir / "review_queue.json"
    atomic_write_json(queue_path, queue)
    print(f"复核队列已生成：{queue_path}")
    print(f"检索窗口：{used_window}；候选论文：{candidate_count} 篇")
    if candidate_count < args.min_results:
        print(
            f"警告：候选 {candidate_count} 篇低于 --min-results {args.min_results}，"
            "复核后的最终推荐量可能不足。",
            file=sys.stderr,
        )
    return queue_path


def deliver_stage(args: argparse.Namespace) -> Path:
    reviewed_path = Path(args.reviewed)
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    summarize_args = ["--input", str(reviewed_path), "--output", str(report_path)]
    # 队列对账（2026-09-08 用户裁定）：复核队列就在 reviewed 同目录，存在就传给
    # summarize，让「队列里有、复核结果里没有」的候选出现在报告头部的本期排除里。
    queue_candidate = reviewed_path.parent / "review_queue.json"
    if queue_candidate.exists():
        summarize_args += ["--queue", str(queue_candidate)]

    # ---- 研究团队补查（2026-09-16 新增）----
    # 只查「已通过复核」的论文，不进检索阶段；必须在 summarize 之前跑，
    # 因为研究团队一行是在渲染时从该字段生成的。
    # 失败不阻塞：最坏结果只是报告没有这一行，不该让整期报告出不来。
    enrich_args = ["--reviewed", str(reviewed_path)]
    if queue_candidate.exists():
        enrich_args += ["--queue", str(queue_candidate)]
    try:
        run_script("enrich_team.py", *enrich_args)
    except subprocess.CalledProcessError as exc:
        print(
            f"警告：研究团队补查失败，报告将不含该字段（不阻塞交付）：{exc}",
            file=sys.stderr,
        )

    run_script("summarize_papers.py", *summarize_args)

    delivery = "local-report"
    should_commit = bool(args.record_local_report)
    if not args.skip_push:
        status_path = report_path.with_suffix(".delivery.json")
        run_script(
            "push_wechat.py",
            "--report", str(report_path),
            "--provider", args.provider,
            "--result-json", str(status_path),
        )
        status = load_json(status_path, {})
        if status.get("configured") and status.get("success"):
            delivery = str(status.get("provider"))
            should_commit = True
        elif not status.get("configured"):
            print("微信推送尚未配置。报告已正常生成；在当前对话展示报告后，可按 local-report 提交历史。")

    if should_commit:
        run_script(
            "deduplicate.py",
            "commit",
            "--input", str(reviewed_path),
            "--history", str(args.history),
            "--delivery", delivery,
        )
        try:
            run_script(
                "update_research_memory.py",
                "learn",
                "--input", str(reviewed_path),
                "--memory", str(args.memory),
                "--profile", str(args.profile),
                "--delivery", delivery,
            )
        except subprocess.CalledProcessError as exc:
            print(
                f"警告：报告交付和历史提交已成功，但研究记忆更新失败：{exc}",
                file=sys.stderr,
            )
    else:
        print("未确认成功交付，因此没有写入推送历史。")
    print(f"报告已生成：{report_path}")
    return report_path


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = ChineseArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    collect_parser = subparsers.add_parser("collect", help="检索、去重、评分并生成复核队列")
    collect_parser.add_argument("--mode", default="all", help="研究配置中定义的模式名称")
    collect_parser.add_argument("--profile", default=str(DEFAULT_PROFILE))
    collect_parser.add_argument("--sources", default="europepmc,crossref,openalex")
    collect_parser.add_argument("--history", default=str(DEFAULT_HISTORY))
    collect_parser.add_argument("--memory", default=str(DEFAULT_MEMORY))
    collect_parser.add_argument("--output-dir")
    collect_parser.add_argument("--threshold", type=int, default=45)
    collect_parser.add_argument("--min-results", type=int, default=5, help="候选量的预警下限；低于此值只报警告，不再触发扩窗")
    collect_parser.add_argument("--max-results", type=int, default=10)
    collect_parser.add_argument("--fresh-days", type=int, default=2, help="新鲜层的出版天数窗口；该层达标论文优先入队")

    deliver_parser = subparsers.add_parser("deliver", help="生成已复核 JSON 报告，并可选择推送")
    deliver_parser.add_argument("--reviewed", required=True)
    deliver_parser.add_argument("--report", required=True)
    deliver_parser.add_argument("--history", default=str(DEFAULT_HISTORY))
    deliver_parser.add_argument("--memory", default=str(DEFAULT_MEMORY))
    deliver_parser.add_argument("--profile", default=str(DEFAULT_PROFILE))
    deliver_parser.add_argument("--provider", choices=("auto", "wxpusher", "serverchan", "wecom"), default="auto")
    deliver_parser.add_argument("--skip-push", action="store_true")
    deliver_parser.add_argument("--record-local-report", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    # 云端沙箱的 shell 状态不跨命令块保留，若只在自举那一步导出过 .env，
    # 本进程就拿不到 OPENALEX_MAILTO 等变量（会静默掉出 OpenAlex 礼貌池）。
    # 此处补载只填空、不覆盖已有环境变量。
    _loaded_env = load_dotenv_if_present()
    if _loaded_env:
        print(f"[env] 已从 .env 补载：{', '.join(_loaded_env)}（值不回显）")
    args = parse_args(argv)
    if args.command == "collect":
        try:
            load_profile(args.profile)
        except ProfileError as exc:
            raise SystemExit(str(exc)) from exc
        if not 0 <= args.threshold <= 100:
            raise SystemExit("--threshold 必须在0到100之间")
        if not 1 <= args.min_results <= args.max_results <= 50:
            raise SystemExit("参数必须满足 1 <= --min-results <= --max-results <= 50")
        collect_stage(args)
    else:
        deliver_stage(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""按照研究配置对规范化论文执行透明的初步评分。"""

from __future__ import annotations

import argparse
import re
from datetime import date, datetime
from math import ceil
from typing import Any

from axes import axes as judge_axes, load_axes_config
from common import ChineseArgumentParser, atomic_write_json, clean_text, extract_papers, load_json, normalize_doi, utc_now_iso
from profile_config import DEFAULT_PROFILE, ProfileError, load_profile, topic_groups

# v13：初筛层 = 三轴 rel + 期刊档位两维加权（0.13/0.87，档差 5 联动）。
# 相关度权重 0.13 由用户锚反推（阶段 3 定稿）。不是「相关度不重要」——
# 影响力 = 权重 × 刻度跨度，rel 跨度（~58）远大于 qual（~10），0.13 时相关度仍是主导方。
# novelty/methodology/inspiration 三维（方法词表命中数映射）已证伪删除（阶段 2 诊断：
# 三者是同一个 7 档整数的三张映射表，Spearman 0.98–0.9972）。
WEIGHTS = {
    "relevance": 0.13,
    "quality": 0.87,
}

# 经鼻优先：命中鼻-脑即不再计入 CNS 递送（2026-09-08 用户裁定）。
# 原分类中 L1 ⊆ L2 是结构性必然——L2 词表含 blood-brain barrier / brain targeting，
# 而每篇鼻-脑论文必然提到这些词，导致鼻-脑天然双命中（relevance 99）而其它方向
# 单命中（50），形成系统性偏袒。互斥后三类真正按给药途径划分。
NASAL_PRIORITY_OVER = ("L1 鼻-脑递送", "L2 CNS 疾病递送")
DEFAULT_DIRECTION_BONUS = 8

DEFAULT_QUALITY_TIERS = {
    "L0": {"nature", "science", "cell"},
    "L1": set(),
    "L2": set(),
    "L3": set(),
    "L4": set(),
}

# v13 五档：L0 正刊(3) / L1 大子刊(14) / L2 高影响子刊(6) / L3 一区强势(9) / L4 一区常规(13)，共 45 本。
# 分档依据不是影响因子或分区，而是「在药物递送语境下的公认地位」。
# 档差 5（L2/L3/L4 = 80/75/70，用户 09-13 裁定「一区刊质量接近，档差 10 过大」），
# 头部断层：L0/L1 走通道 B 独立门槛，不参与通道 A 连续排序。
QUALITY_TIER_KEYS = ("L0", "L1", "L2", "L3", "L4")
QUALITY_TIER_SCORES = {"L0": 100, "L1": 92, "L2": 80, "L3": 75, "L4": 70}
# 期刊未分层 / 缺失 / 预印本的分数（与档位表同一把尺子，已按新标尺重标定）
QUALITY_UNLISTED_SCORE = 55
QUALITY_MISSING_SCORE = 35
QUALITY_PREPRINT_SCORE = 42
QUALITY_REVIEW_CAP = 80

EXCLUDE_TYPES = (
    "editorial", "correction", "erratum", "retraction", "conference abstract", "letter to the editor"
)


def contains_any(text: str, terms: list[str] | tuple[str, ...] | set[str]) -> bool:
    return any(clean_text(term).casefold() in text for term in terms if clean_text(term))


_JOURNAL_LOCATION_PAREN = re.compile(r"\s*\([^()]*\)\s*$")


def normalize_journal(journal: str) -> str:
    """把期刊名归一化成可比较的键。

    实测发现数据源实际返回的写法有三类陷阱，不处理会让白名单与
    quality_tiers 静默失配（38 本白名单里曾因此漏掉 9 本）：

    1. 地名限定符：Europe PMC resultType=core 的 journalTitle 为 None，
       回落到 journalInfo.journal.title，形如
       "Advanced materials (Deerfield Beach, Fla.)"。
    2. MEDLINE 句点分节："Materials today. Bio"、"Cell reports. Medicine"。
    3. 冒号副标题："Journal of controlled release : official journal of ..."。

    剥括号必须早于剥冒号，否则 "(New York, N.Y. : 1989)" 这类括号内带冒号的
    写法会被冒号切掉半个括号，留下无法闭合的残串。
    """
    text = re.sub(r"\s+", " ", journal.casefold().replace("the ", "", 1)).strip()
    for _ in range(2):
        stripped = _JOURNAL_LOCATION_PAREN.sub("", text).strip()
        if stripped == text:
            break
        text = stripped
    text = re.split(r"\s*:\s*", text, maxsplit=1)[0].strip()
    return text.replace(".", "").strip()


def journal_index(profile: dict[str, Any]) -> dict[str, tuple[str, str]]:
    """把 profile.journal_gate 展平成 {归一化写法: (通道, 规范名)}。

    通道是单值而非集合：A = 主题驱动刊（必须命中窄层主题才入选），
    B = 顶刊（命中任意药物递送细分即可入选）。两组期刊应当互不重叠；
    万一重叠，以 B 为准——顶刊通道的口径更宽，且期刊水平更高。

    复用 normalize_journal()，保证与 quality_tiers 的匹配语义完全一致。
    gate 缺失或未启用时返回空字典，调用方据此退化为原版行为（不做期刊硬过滤）。
    """
    gate = profile.get("journal_gate")
    if not isinstance(gate, dict) or not gate.get("enabled"):
        return {}
    index: dict[str, tuple[str, str]] = {}
    # 先读 A 再读 B，后写的 B 覆盖先写的 A，实现 B 优先
    for field, channel in (("channel_a", "A"), ("channel_b", "B")):
        for entry in gate.get(field) or []:
            if not isinstance(entry, dict):
                continue
            name = clean_text(entry.get("name"))
            aliases = [clean_text(v) for v in entry.get("aliases") or []]
            variants = [v for v in [name, *aliases] if v]
            if not variants:
                continue
            for variant in variants:
                key = normalize_journal(variant)
                if key:
                    index[key] = (channel, name)
    return index


def assign_channels(paper: dict[str, Any], index: dict[str, tuple[str, str]]) -> tuple[set[str], str]:
    """返回 (命中的通道集合, 规范期刊名)。

    集合里最多一个元素（"A" 或 "B"）。index 为空（未启用白名单）时返回空集合，
    调用方不得据此剔除。
    """
    raw = clean_text(paper.get("journal"))
    if not index:
        return set(), raw
    key = normalize_journal(raw)
    if not key:
        return set(), ""
    found = index.get(key)
    if not found:
        return set(), raw
    channel, canonical = found
    return {channel}, canonical


def channel_b_topic_groups(profile: dict[str, Any]) -> list[dict[str, Any]]:
    """通道 B 的「任意药物递送细分」词表，结构与 topic_groups 相同。

    只在论文命中通道 B 时并入打分，避免给通道 A 的论文误加分。
    """
    groups: list[dict[str, Any]] = []
    for item in profile.get("topic_groups_channel_b") or []:
        if not isinstance(item, dict):
            continue
        label = clean_text(item.get("label"))
        terms = [clean_text(v) for v in item.get("terms") or [] if clean_text(v)]
        try:
            weight = int(item.get("weight") or 0)
        except (TypeError, ValueError):
            weight = 0
        if label and terms:
            groups.append({"label": label, "weight": weight, "terms": terms})
    return groups


def _group_hit(text: str, group: dict[str, Any]) -> bool:
    """判断单篇论文是否命中某个主题组。

    窄层组可带 require_terms 门禁：命中 terms 里的主题词、且命中
    require_terms 里的递送词，才算命中。这样把「疾病名词/脑区地名」与
    「递送动作」解耦——glioblastoma、Alzheimer、olfactory bulb 等词只有
    与 delivery/nanoparticle/carrier 等递送词共现时，才表示递送研究。
    require_terms 为空时退化为「命中任意 terms 即算命中」（宽层与旧行为）。
    """
    if not contains_any(text, group["terms"]):
        return False
    require = group.get("require_terms") or []
    if require and not contains_any(text, require):
        return False
    return True


def score_relevance(
    text: str, profile: dict[str, Any], channels: set[str] | None = None
) -> tuple[int, list[str], list[str], list[str]]:
    """返回 (relevance, 参与评分的主题标签, 证据, 命中的窄层主题标签)。

    两个通道用的是同一套主题的两层口径，不是两套并列体系：
      - 窄层 = L1/L2/L3 细分方向（topic_groups）
      - 宽层 = 任意药物递送细分（topic_groups_channel_b）
    通道 A 的期刊必须命中窄层才入选；通道 B 的顶刊命中宽层即可入选。
    若还额外命中窄层，则按 journal_gate.narrow_bonus_* 加分——
    「顶刊上出现自己最关注的细分方向」比「顶刊上的普通递送论文」更值得读，
    所以体现为提分与提优先级，而不是并列标成第二个通道。

    加分不在这里加：relevance 末尾有 min(100, ...)，而实测语料里大量论文
    已经撞到 100，加在里面会被静默吃掉（实测 100 -> 100，加分完全失效）。
    加分改由 rank_one() 在加权总分之外单独施加，见 narrow_priority_bonus()。
    """
    narrow_groups = topic_groups(profile)
    narrow_labels = [g["label"] for g in narrow_groups if _group_hit(text, g)]
    # 经鼻优先：命中鼻-脑后不再计入 CNS 递送。原分类 L1 ⊆ L2 是结构性必然
    # （L2 词表含 blood-brain barrier / brain targeting，鼻-脑论文必然提及），
    # 造成鼻-脑天然双命中而其它方向单命中。互斥后三类真正按给药途径划分。
    if NASAL_PRIORITY_OVER[0] in narrow_labels and NASAL_PRIORITY_OVER[1] in narrow_labels:
        narrow_labels.remove(NASAL_PRIORITY_OVER[1])

    if channels and "B" in channels:
        scoring_groups = channel_b_topic_groups(profile)
        labels = [g["label"] for g in scoring_groups if _group_hit(text, g)]
    else:
        scoring_groups = narrow_groups
        labels = narrow_labels
    weights = {g["label"]: int(g["weight"]) for g in scoring_groups}
    raw = sum(weights[label] for label in labels)
    evidence = [f"匹配主题：{label}" for label in labels]

    for item in profile.get("cross_topic_bonuses") or []:
        if not isinstance(item, dict):
            continue
        required = [clean_text(value) for value in item.get("labels") or [] if clean_text(value)]
        try:
            bonus = int(item.get("bonus") or 0)
        except (TypeError, ValueError):
            continue
        if required and all(label in labels for label in required):
            raw += max(0, min(50, bonus))
            evidence.append(clean_text(item.get("reason")) or f"交叉主题加分：{' + '.join(required)}")
    if len(labels) >= 2:
        raw += min(10, (len(labels) - 1) * 3)
    # 单组命中保底（2026-09-04 引入）已于 2026-09-08 移除：
    # relevance 不再参与加权，只作准入信号，抬高其数值已无意义；且互斥后候选
    # 几乎全是单组命中，「单组 vs 多组」的不对称消失，保底失去存在前提。
    # 方向优先级改由 nasal_direction_bonus() 在加权总分之外单独表达。
    return min(100, raw), labels, evidence, narrow_labels


def narrow_topic_bonus(profile: dict[str, Any], hit_count: int) -> int:
    """通道 B 顶刊论文额外命中窄层主题时的加分。未配置时用保守默认值。"""
    gate = profile.get("journal_gate")
    gate = gate if isinstance(gate, dict) else {}
    try:
        per = int(gate.get("narrow_bonus_per_group") or 10)
    except (TypeError, ValueError):
        per = 10
    try:
        cap = int(gate.get("narrow_bonus_cap") or 24)
    except (TypeError, ValueError):
        cap = 24
    return max(0, min(cap, per * hit_count))


def narrow_priority_bonus(
    channels: set[str], narrow_topics: list[str], profile: dict[str, Any]
) -> tuple[int, list[str]]:
    """顶刊额外命中窄层细分方向时，在加权总分之外单独施加的优先级加分。

    为什么不直接加进 relevance：relevance 末尾有 min(100, ...) 封顶，
    实测语料中大量论文已经撞到 100（65 篇里 18 篇，28%），
    加在封顶以内会被静默吃掉，导致「顶刊命中细分方向」与「顶刊普通递送论文」
    拿到完全相同的分数，这个加分形同虚设。
    加在加权总分之外同样需要封顶（保持 0-100），但此时只有已经接近满分的
    论文才会再次饱和，绝大多数语料能体现出差距。
    """
    if not (channels and "B" in channels) or not narrow_topics:
        return 0, []
    add = narrow_topic_bonus(profile, len(narrow_topics))
    if not add:
        return 0, []
    return add, [f"顶刊 × 配置关注方向（{' + '.join(narrow_topics)}）：优先级 +{add}"]


def nasal_direction_bonus(
    narrow_topics: list[str], profile: dict[str, Any]
) -> tuple[int, list[str]]:
    """核心方向加分（2026-09-08 用户裁定）。

    互斥后三类各占一条给药途径、relevance 不再区分方向（已改为准入条件），
    用户的核心方向（鼻-脑）因此失去原有排序优势——实测互斥后鼻-脑两篇从
    81/72 掉到 69/65 落到推荐线下。而这两篇偏低是方法词表失效所致
    （烟草 EV 命中的是 clinical_translational + safety_and_toxicity，
    与制剂方法学无关；氧化铈摘要缺失），并非方向本身价值低。
    故在加权总分之外单独给核心方向加分，用加分表达优先级，而不是压低其它方向。

    加分项可在 profile 的 direction_bonus 中配置；未配置时默认给鼻-脑
    DEFAULT_DIRECTION_BONUS 分。与 priority_bonus 同机制（总分之外，避开封顶）。
    """
    bonus_map = profile.get("direction_bonus")
    if not isinstance(bonus_map, dict):
        bonus_map = {}
    add = 0
    labels: list[str] = []
    for label in narrow_topics:
        default = DEFAULT_DIRECTION_BONUS if label == NASAL_PRIORITY_OVER[0] else 0
        try:
            value = int(bonus_map.get(label, default))
        except (TypeError, ValueError):
            value = default
        if value:
            add += value
            labels.append(f"核心方向（{label}）：优先级 +{value}")
    return add, labels


def configured_quality_tiers(profile: dict[str, Any]) -> dict[str, set[str]]:
    configured = profile.get("quality_tiers") or {}
    tiers: dict[str, set[str]] = {}
    for tier in QUALITY_TIER_KEYS:
        values = {normalize_journal(clean_text(item)) for item in configured.get(tier, []) if clean_text(item)}
        tiers[tier] = values or set(DEFAULT_QUALITY_TIERS[tier])
    # 向后兼容：拆档前只写了 tier_2 的旧 profile，其期刊归入 L3（中档）。
    legacy = {
        normalize_journal(clean_text(item)) for item in configured.get("tier_2", []) if clean_text(item)
    }
    if legacy:
        tiers["L3"] = tiers["L3"] | legacy
    return tiers


def score_quality(
    paper: dict[str, Any], profile: dict[str, Any], canonical_journal: str = ""
) -> tuple[int, list[str]]:
    """给期刊打分。

    `canonical_journal` 是 assign_channels() 从 journal_gate 白名单解析出的规范刊名。
    白名单配了别名（如 PNAS 的 3 个缩写），但 quality_tiers 每本刊只存 1 种写法；
    若直接用数据源返回的缩写去查档位，会静默掉进「未分层 55」，把本该入选的文章
    压到线外。因此这里优先用规范名查档位，查不到再回退原始写法（保留未分层兜底）。
    """
    journal = normalize_journal(clean_text(paper.get("journal")))
    # 规范名本身未经归一化（journal_index 存的是原始 name），须归一化后与 tier 的键对齐。
    canon_key = normalize_journal(clean_text(canonical_journal)) if canonical_journal else ""
    article_type = clean_text(paper.get("article_type")).casefold()
    tiers = configured_quality_tiers(profile)
    evidence: list[str] = []
    if paper.get("is_preprint") or journal in {"biorxiv", "medrxiv"}:
        score = QUALITY_PREPRINT_SCORE
        evidence.append("预印本：尚未完成正式同行评议")
    else:
        matched_tier = None
        # 优先用规范名查档位（白名单别名），查不到再回退原始写法
        for tier in QUALITY_TIER_KEYS:
            if canon_key and canon_key in tiers[tier]:
                matched_tier = tier
                break
        if matched_tier is None:
            for tier in QUALITY_TIER_KEYS:
                if journal and journal in tiers[tier]:
                    matched_tier = tier
                    break
        if matched_tier:
            score = QUALITY_TIER_SCORES[matched_tier]
            evidence.append(f"命中期刊档位 {matched_tier}")
        elif journal:
            score = QUALITY_UNLISTED_SCORE
            evidence.append("期刊未分层，需根据单篇设计人工核实")
        else:
            score = QUALITY_MISSING_SCORE
            evidence.append("期刊信息缺失")
    # 综述判定：兼容三源原始标签（review / Review; Journal Article）与复核后的人工判定值（中文"综述"）。
    # 复核环节会读摘要后把 article_type 改写为"综述"/"研究论文"，故此处须同时识别中英文标记。
    if "review" in article_type or "综述" in article_type or "綜述" in article_type:
        score = min(score, QUALITY_REVIEW_CAP)
        evidence.append("综述需按证据综合质量而非原始实验完整性评价")
    # v13：期刊档位分是干净的 5 档值（100/92/80/75/70），不再叠加「有摘要 +3」。
    # 原「有摘要 +3」是数据可得性加分，与 09-07「数据可得性 ≠ 论文质量」原则矛盾，
    # 且让 quality 多出第 6 个离散值（83 = 80+3），已被 v13 定稿废除。
    # 摘要缺失仍不扣分——「拿不到摘要」是检索源问题，由复核环节核实，不重复计分。
    return max(0, min(100, score)), evidence


def exclusion_reasons(
    paper: dict[str, Any], text: str, relevance: int, profile: dict[str, Any],
    channels: set[str] | None = None, gate_enabled: bool = False,
    topics: list[str] | None = None,
) -> list[str]:
    reasons: list[str] = []
    article_type = clean_text(paper.get("article_type")).casefold()
    title = clean_text(paper.get("title")).casefold()
    if contains_any(article_type, EXCLUDE_TYPES) or contains_any(title, EXCLUDE_TYPES):
        reasons.append("非研究性文章、勘误或撤稿类内容")
    # 期刊白名单是硬门槛：不在名单内的期刊直接剔除，而不是降分
    if gate_enabled and not channels:
        reasons.append("期刊不在白名单内：" + (clean_text(paper.get("journal")) or "缺失"))
    # 2026-09-08：relevance 改为准入条件（不再参与加权），准入判定随之改成
    # 「是否命中任一研究方向」的布尔判断，而不是看分数高低——阈值式判定
    # 会让「命中了弱组」的论文被静默淘汰，而是否真的该淘汰应由复核环节
    # 阅读证据后判断（通道 B 尤其如此：顶刊上的递送论文可能只命中宽层一组）。
    if not topics:
        reasons.append("未命中任何已配置研究方向")
    exclusions = [clean_text(item).casefold() for item in profile.get("exclusion_terms") or []]
    matched = [term for term in exclusions if term and term in text]
    if matched:
        reasons.append("命中配置的排除词：" + ", ".join(matched[:5]))
    if not paper.get("title"):
        reasons.append("题名缺失")
    return reasons


def strong_recommendation(
    topics: list[str], methods: list[str], score: int, profile: dict[str, Any]
) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    for item in profile.get("strong_recommendation_rules") or []:
        if not isinstance(item, dict):
            continue
        required_topics = [clean_text(value) for value in item.get("labels") or [] if clean_text(value)]
        required_methods = [clean_text(value) for value in item.get("methods") or [] if clean_text(value)]
        try:
            minimum = int(item.get("min_score") or 80)
        except (TypeError, ValueError):
            minimum = 80
        if (
            score >= minimum
            and required_topics
            and all(label in topics for label in required_topics)
            and all(label in methods for label in required_methods)
        ):
            reasons.append(clean_text(item.get("reason")) or "满足配置的强烈推荐条件")
    return bool(reasons), reasons


def rank_one(
    paper: dict[str, Any],
    profile: dict[str, Any],
    index: dict[str, tuple[str, str]] | None = None,
) -> dict[str, Any]:
    """对单篇论文评分。`index` 可省略——省略时现场构建期刊索引。

    批量调用时务必传入 `journal_index(profile)` 的结果，否则每篇都会重建
    一次索引（41 本刊 × 107 条写法）。保留默认值的目的是不破坏既有的
    单篇调用方式（原本签名为 rank_one(paper, profile)）。
    """
    if index is None:
        index = journal_index(profile)
    text = f" {paper.get('title', '')} {paper.get('abstract', '')} ".casefold()
    channels, canonical_journal = assign_channels(paper, index)
    gate_enabled = bool(index)
    relevance, topics, relevance_evidence, narrow_topics = score_relevance(text, profile, channels)
    axes_cfg = load_axes_config(profile)
    ax = judge_axes(text, paper.get("article_type"), axes_cfg)
    rel = ax["relevance"]
    axes_desc = ""
    if axes_cfg and ax.get("primary"):
        p = ax["primary"]
        axes_desc = f"{axes_cfg['primary'].get('name', '主轴')}={p['label']}（{p['src']}）"
        for m, mc in zip(ax.get("modulators") or [], axes_cfg.get("modulators") or []):
            axes_desc += f" {mc.get('name', '')}={m['label']}"
    quality, quality_evidence = score_quality(paper, profile, canonical_journal)
    component_scores = {
        "relevance": rel,
        "quality": quality,
    }
    base_score = round(sum(component_scores[key] * WEIGHTS[key] for key in WEIGHTS))
    # 顶刊额外命中窄层细分方向 -> 在加权总分之外单独加优先级分（v13 保留）。
    priority_bonus, priority_evidence = narrow_priority_bonus(channels, narrow_topics, profile)
    direction_bonus, direction_evidence = nasal_direction_bonus(narrow_topics, profile)
    score = max(0, min(100, base_score + priority_bonus + direction_bonus))
    reasons = exclusion_reasons(paper, text, relevance, profile, channels, gate_enabled, topics=topics)
    # 强烈推荐在 v13 交 AI 复核层判定；初筛层方法词表已删，methods 传空（规则退化）。
    strong, strong_reasons = strong_recommendation(topics, [], score, profile)
    ranked = dict(paper)
    ranked["doi"] = normalize_doi(ranked.get("doi"))
    ranked.update(
        {
            "recommendation_score": score,
            "base_score": base_score,
            "priority_bonus": priority_bonus,
            "direction_bonus": direction_bonus,
            "score_status": "preliminary_metadata_score",
            "component_scores": component_scores,
            "score_weights": WEIGHTS,
            "matched_topics": topics,
            "matched_narrow_topics": narrow_topics,
            "channels": sorted(channels),
            "journal_canonical": canonical_journal,
            "axes": {
                "primary": ax["primary"],
                "modulators": ax["modulators"],
                "is_review": ax["is_review"],
            },
            "score_evidence": {
                "relevance": relevance_evidence,
                "quality": quality_evidence,
                "axes": [axes_desc],
                "priority": priority_evidence,
                "direction": direction_evidence,
            },
            "excluded": bool(reasons),
            "exclusion_reasons": reasons,
            "strong_recommendation_candidate": strong,
            "strong_recommendation_reasons": strong_reasons,
        }
    )
    return ranked


def publication_age_days(value: Any, today: date) -> int | None:
    """把出版日期换算成距今天数；无法解析（缺失或只有年月）时返回 None。"""
    text = clean_text(value)
    if not text:
        return None
    parts = text.split("T")[0].strip().split("-")
    try:
        if len(parts) >= 3:
            parsed = date(int(parts[0]), int(parts[1]), int(parts[2]))
        elif len(parts) == 2:
            parsed = date(int(parts[0]), int(parts[1]), 1)
        else:
            parsed = date(int(parts[0]), 1, 1)
    except (TypeError, ValueError):
        return None
    return (today - parsed).days


def rank_payload(
    payload: Any, profile: dict[str, Any], *, threshold: int = 45, maximum: int = 10,
    fresh_days: int = 2, fresh_share: float = 0.5,
) -> dict[str, Any]:
    papers = extract_papers(payload)
    index = journal_index(profile)
    ranked = [rank_one(paper, profile, index) for paper in papers]
    # 同分时，顶刊上命中窄层细分方向的排前面：封顶可能让两篇都到 100，
    # 此时 priority_bonus 在分数上看不出差别，用布尔量再断一次。
    ranked.sort(
        key=lambda item: (
            item["excluded"],
            -item["recommendation_score"],
            -int(bool(item.get("matched_narrow_topics"))),
            item.get("title", ""),
        )
    )
    today = datetime.now().astimezone().date()
    for item in ranked:
        age = publication_age_days(item.get("publication_date"), today)
        item["age_days"] = age
        item["in_fresh_window"] = age is not None and 0 <= age <= fresh_days
    # 通道 B（顶刊）绕过初筛线：期刊白名单本身已是最强筛选，是否真的属于药物递送
    # 领域由复核环节阅读证据后判定（delivery_centrality），不让元数据初筛分抢先淘汰
    # ——2026-09-08 用户裁定。实测若按分数筛，本周唯一的通道 B 论文（纯机制研究）
    # 会以「分数不够」被排除，用户看到的是「没搜到」，而非「搜到后判为不相关」。
    passing = [
        item for item in ranked
        if not item["excluded"]
        and (
            item["recommendation_score"] >= threshold
            or "B" in (item.get("channels") or [])
        )
    ]
    # 分层名额：新鲜层（近 fresh_days 天）的达标候选先全部入队，再由归档层按初筛分补足。
    # 这样新的论文不会因整体分数偏低而被 maximum 截断挤掉，同时保证候选量足够支撑复核后的产出。
    fresh = [item for item in passing if item["in_fresh_window"]]
    archive = [item for item in passing if not item["in_fresh_window"]]
    # 新鲜层只拿保底配额（默认占队列上限的一半），剩下的名额留给归档层按初筛分竞争。
    # 否则新鲜层一旦膨胀就会独占队列，把分数更高的近期论文（含高分真阳性）挤掉。
    fresh_quota = max(1, ceil(maximum * max(0.0, min(1.0, fresh_share)))) if fresh else 0
    fresh_taken = fresh[:fresh_quota]
    archive_taken = archive[: max(0, maximum - len(fresh_taken))]
    leftover = maximum - len(fresh_taken) - len(archive_taken)
    if leftover > 0:
        fresh_taken += fresh[fresh_quota : fresh_quota + leftover]
    recommendations = fresh_taken + archive_taken
    not_in_allowlist = sum(
        1 for item in ranked if any("白名单" in r for r in item.get("exclusion_reasons") or [])
    )
    channel_counts = {
        "A": sum(1 for item in passing if "A" in (item.get("channels") or [])),
        "B": sum(1 for item in passing if "B" in (item.get("channels") or [])),
        # 顶刊（通道 B）上额外命中窄层关注方向的论文：不是第二个通道，
        # 而是加分与优先级的体现，单独计数便于核对加分是否生效。
        "B_hit_narrow": sum(
            1
            for item in passing
            if "B" in (item.get("channels") or []) and (item.get("matched_narrow_topics") or [])
        ),
    }
    return {
        "generated_at": utc_now_iso(),
        "profile_name": clean_text(profile.get("profile_name")),
        "threshold": threshold,
        "maximum": maximum,
        "fresh_days": fresh_days,
        "fresh_share": fresh_share,
        "screened_count": len(ranked),
        "passing_count": len(passing),
        "fresh_window_count": len(fresh),
        "recommended_count": len(recommendations),
        "journal_gate_enabled": bool(index),
        "not_in_allowlist_count": not_in_allowlist,
        "channel_counts": channel_counts,
        "selection_note": (
            f"候选分两层入队：新鲜层为近 {fresh_days} 天内出版的达标论文（{len(fresh)} 篇），"
            f"最多占队列的 {max(0.0, min(1.0, fresh_share)):.0%}（{fresh_quota} 个名额）；"
            f"其余名额由更早的达标论文按初筛分补足（上限 {maximum}）。"
            f"本次入队新鲜层 {len(fresh_taken)} 篇、归档层 {len(archive_taken)} 篇；"
            f"两层内部各按初筛分降序，新鲜层排在前面以便优先复核。"
        ),
        "formula": (
            "relevance*0.13 + quality*0.87；relevance = 三轴 R/F/D 关键词判读的契合度分"
            "（rel = 100×R×(0.65+0.35D)×(0.80+0.20F)）；方向命中（topic_groups）为准入条件"
        ),
        "important_note": (
            "分数是关键词驱动的元数据初筛分（三轴 R/F/D 粗判 + 期刊档位）。"
            "三轴与最终评分（rel+content+qual）由 AI 复核层读摘要精判，"
            "初筛只做砍量 + 粗排 + 零误杀准入。"
        ),
        "recommendations": recommendations,
        "ranked_papers": ranked,
    }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = ChineseArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--profile", default=str(DEFAULT_PROFILE))
    parser.add_argument("--threshold", type=int, default=45)
    parser.add_argument("--max-results", type=int, default=10)
    parser.add_argument("--fresh-days", type=int, default=2)
    parser.add_argument("--fresh-share", type=float, default=0.5)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if not 0 <= args.threshold <= 100:
        raise SystemExit("--threshold 必须在0到100之间")
    if not 1 <= args.max_results <= 50:
        raise SystemExit("--max-results 必须在1到50之间")
    if not 1 <= args.fresh_days <= 30:
        raise SystemExit("--fresh-days 必须在1到30之间")
    if not 0.0 <= args.fresh_share <= 1.0:
        raise SystemExit("--fresh-share 必须在0到1之间")
    try:
        profile = load_profile(args.profile)
    except ProfileError as exc:
        raise SystemExit(str(exc)) from exc
    result = rank_payload(
        load_json(args.input, {}),
        profile,
        threshold=args.threshold,
        maximum=args.max_results,
        fresh_days=args.fresh_days,
        fresh_share=args.fresh_share,
    )
    atomic_write_json(args.output, result)
    summary = (
        f"共初筛 {result['screened_count']} 篇论文；"
        f"{result['passing_count']} 篇达到初步阈值，其中 {result['fresh_window_count']} 篇在近 {args.fresh_days} 天窗口内；"
        f"入队 {result['recommended_count']} 篇。"
    )
    if result.get("journal_gate_enabled"):
        counts = result.get("channel_counts") or {}
        summary += (
            f" 期刊白名单已启用：白名单外剔除 {result.get('not_in_allowlist_count', 0)} 篇；"
            f"达标论文通道分布 A {counts.get('A', 0)} / B {counts.get('B', 0)} 篇；"
            f"其中顶刊额外命中细分方向、已按配置加分的 {counts.get('B_hit_narrow', 0)} 篇。"
        )
    print(summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

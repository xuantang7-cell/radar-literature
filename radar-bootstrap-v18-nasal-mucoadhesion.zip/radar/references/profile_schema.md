# 研究配置结构

公开版本中的 `config/research_profile.json` 有意保持空白。只有必填字段已经填写完整时，才能把 `configured` 设置为 `true`。

## 必填字段

- `profile_name`：显示在运行元数据中的简短配置名称。
- `research_context`：用于帮助判断相关性的精简研究背景。
- `target_system`：生物、疾病、材料、技术、人群或其他主要研究对象。
- `priority_questions`：指导最终证据复核的核心科学问题。
- `queries`：默认 `all` 模式使用的布尔式 API 查询语句。
- `topic_groups`：用于确定性初筛的主题组。每一项包含 `label`、1–100的 `weight` 和非空 `terms` 数组。

至少需要一条查询和一个有效主题组。配置为空时，程序会提示配置错误并停止，不能返回无关论文。

## 可选字段

- `modes`：命名的聚焦模式。每个键对应一个包含 `queries` 数组的对象。
- `cross_topic_bonuses`：包含 `labels`、`bonus` 和可选 `reason` 的条目。只有列出的全部主题组都命中时才应用加分。
- `topic_groups_channel_b`：通道 B（顶刊）专用的**宽层**主题组。格式同 `topic_groups`。
  未配置时通道 B 退回使用 `topic_groups`，此时顶刊论文会因口径过窄而大量漏选。
- `method_groups`：已废弃（v13 删三维 novelty/methodology/inspiration，方法词表不再参与评分）。
- `journal_gate`：期刊白名单与双通道配置，见下方专节。未配置或 `enabled` 为 `false`
  时退化为原版行为（不做期刊硬过滤）。
- `quality_tiers`：由 `L0`、`L1`、`L2`、`L3`、`L4` 五档组成的规范化期刊名称数组
  （v13 分档：正刊/大子刊/高影响子刊/一区强势/一区常规，分值 100/92/80/75/70）。
  白名单里的每一本刊都应出现在其中，否则 `score_quality` 会按"未分层"给分。
- `exclusion_terms`：题名或摘要命中后触发初步排除的词语。该列表应保持保守。
- `mechanistic_terms`：提示机制性证据或高信息量证据的领域专用术语。
- `strong_recommendation_rules`：包含 `labels`、可选 `methods`、`min_score` 和 `reason` 的条目。所有已配置条件都必须同时命中。
- `roadmap_stages`：包含 `label` 和 `keywords` 的条目，只用于在研究记忆中归类已经确认的报告。
- `tags`：偏好的报告标签。

## `journal_gate`：期刊白名单与双通道

```json
"journal_gate": {
  "enabled": true,
  "channel_a": [{"name": "期刊规范名", "aliases": ["实测写法1", "实测写法2"]}],
  "channel_b": [{"name": "...", "aliases": ["..."]}],
  "narrow_bonus_per_group": 12,
  "narrow_bonus_cap": 24
}
```

- `enabled`：为 `false` 或整个字段缺失时，退化为原版行为（不做期刊硬过滤）。
- `channel_a` / `channel_b`：两本名单**应当互不重叠**。万一写重了，以 B 为准 ——
  顶刊通道口径更宽、门槛更高。
- `name`：只用于显示与回填 `journal_canonical`，不参与匹配。
- `aliases`：**必须是实测命中过的写法全列表**。匹配经过 `normalize_journal()`
  归一化后做精确等值比较，不是包含匹配，所以漏一个写法就会静默失配。
  至少应包含两种：MEDLINE 全称（含地名限定符）与 MEDLINE 缩写。

### 为什么必须枚举实测写法

数据源实际返回四类写法，不处理会让白名单与 `quality_tiers` 静默失配：

1. **地名限定符**：`Advanced materials (Deerfield Beach, Fla.)`
2. **MEDLINE 句点分节**：`Materials today. Bio`、`Cell reports. Medicine`
3. **冒号副标题**：`Journal of controlled release : official journal of ...`
4. **等号中文副名**（2026-09-12 实测新增）：`Chinese chemical letters = Zhongguo hua xue kuai bao`

`normalize_journal()` 会依次剥掉末尾地名括号（最多两层）、剥冒号副标题、去句点
—— 顺序不能反，否则 `(New York, N.Y. : 1989)` 会被冒号切掉半个括号。

第 1、2、3 类由 `normalize_journal()` 自动消化；**第 4 类不会**——等号及其后的中文刊名
既不在末尾括号内、也不在冒号后，会被原样保留，造成该刊**整刊静默失配**。
这类写法只能在 `aliases` 里显式枚举（`Chinese Chemical Letters` 已按实测写入）。
**新增中文刊时务必先实测。**

**Europe PMC 的 `JOURNAL:` 字段只索引 MEDLINE 缩写**，用规范全称查会返回 0
（`JOURNAL:"Advanced Materials"` → 0；`JOURNAL:"Adv Mater"` → 28924）。
新增期刊前应先实测该刊在数据源里的真实写法，不要照抄刊名。

### `narrow_bonus_per_group` / `narrow_bonus_cap`

通道 B 的顶刊论文若额外命中 `topic_groups`（窄层细分方向），每条命中加
`narrow_bonus_per_group` 分，总额封顶 `narrow_bonus_cap`。

**这个加分施加在加权总分之外，不在 `relevance` 内部。** 原因是
`score_relevance` 尾部有 `min(100, ...)` 封顶，实测语料中大量论文已经撞顶，
加在封顶以内会被静默吃掉（曾实测 100 → 100，综合分反而倒挂）。
任何新增加分都应当先确认它是否会被封顶吞掉。

程序输出的对应字段：`priority_bonus`（加分值）、`base_score`（未加分的加权总分）、
`recommendation_score = clamp(base_score + priority_bonus)`、
`score_evidence.priority`（加分说明）、`matched_narrow_topics`（命中的窄层标签）。
排序对同分论文还会用 `matched_narrow_topics` 是否非空做 tie-break。

## 权重和关键词命中只用于初步排序

权重和关键词命中只用于初步排序，不是最终证据。Codex 仍必须阅读可用摘要或全文，并独立重新评价每篇候选论文。
